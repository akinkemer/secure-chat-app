import React from "react";
import {InputText} from "primereact/inputtext";
import {InputTextarea} from "primereact/inputtextarea";
import PropTypes from "prop-types";

export default function Input(props) {
    const {errorText, label, value, onChange, name, leftIcon, placeholder, inputTextArea, type, onKeyPress} = props;

    return (
        <div className="py-2">
            <label className="block my-2">{label}</label>
            <span className={leftIcon && "p-input-icon-left"}>
                <i className={`pi pi-${leftIcon}`}/>
                {inputTextArea ? (
                    <InputTextarea
                        style={{width: "100%"}}
                        name={name}
                        className={errorText && "p-invalid"}
                        value={value}
                        onChange={onChange}
                        rows={5}
                        cols={30}
                        autoResize
                        placeholder={placeholder}
                        onKeyPress={onKeyPress}

                    />
                ) : (
                    <InputText type={type} style={{width: "100%"}} name={name} className={errorText && "p-invalid"}
                               onKeyPress={onKeyPress}
                               value={value} onChange={onChange} placeholder={placeholder}/>
                )}
            </span>
            {errorText && <small className="p-error block py-1">{errorText}</small>}
        </div>
    );
}

Input.propTypes = {
    errorText: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
    label: PropTypes.string,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    onChange: PropTypes.func,
    name: PropTypes.string,
    leftIcon: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
    placeholder: PropTypes.string,
    inputTextArea: PropTypes.bool,
    type: PropTypes.string,
};
