import React, { useState } from "react";
import classNames from "classnames";
import AppMenu from "./AppMenu";
import { api } from "../../services/api";
import { useHistory } from "react-router-dom";
import profile from "../../assets/images/profile.svg";
import Modal from "../Modal";
import Input from "../Input";
import { Toast, securePassword } from "../../utils";

const AppTopbar = (props) => {
  const history = useHistory();
  let parseStorage = JSON.parse(localStorage.getItem("user"));
  const userId = JSON.parse(localStorage.getItem("user"))?.id;
  const userInfo = parseStorage?.name + " " + parseStorage?.surname;

  const emptyState = {
    currentPassword: "",
    newPassword: "",
    reNewPassword: "",
  };

  const [state, setState] = useState(emptyState);

  const [visible, setVisible] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const logout = async () => {
    const { data = {}, error } = await api.auth.logout({ userId });
    localStorage.clear();
    history.push("/");
  };

  const hideModal = () => {
    setVisible(false);
  };

  const onChange = (e) => {
    setState({ ...state, [e.target.name]: e.target.value });
  };

  const handleChangePassword = async () => {
    setSubmitted(true);
    const { currentPassword, newPassword, reNewPassword } = state;

    if (!newPassword || !reNewPassword || !currentPassword) return;
    if (newPassword !== reNewPassword) return Toast.warning("Şifreler uyuşmuyor");
    if (newPassword.length < 8) return Toast.warning("Şifreniz en az 8 karakterden oluşmalıdır");
    if (securePassword(newPassword)) {
      return Toast.warning("Şifreniz en az bir büyük bir küçük harf, en az 1 rakam, en az bir özel karakter içermeli ve özel karakterler peş peşe girilemez.");
    }

    const params = {
      currentPassword: currentPassword,
      newPassword: newPassword,
    };
    const { data = {}, error } = await api.auth.changePassword({ ...params }, userId);

    if (error) return Toast.error(error);

    Toast.success(data);

    hideModal();
  };
  return (
    <div className="layout-topbar">
      <div className="layout-topbar-wrapper">
        <div className="layout-topbar-left">
          <button tabIndex="0" className="menu-button p-link" onClick={props.onMenuButtonClick}>
            <i className="pi pi-bars"></i>
          </button>
        </div>

        <AppMenu
          menuMode={props.menuMode}
          sidebarActive={props.sidebarActive}
          sidebarStatic={props.sidebarStatic}
          model={props.menu}
          menuActive={props.menuActive}
          onRootMenuItemClick={props.onRootMenuItemClick}
          onMobileMenuActive={props.onMobileMenuActive}
          onMenuItemClick={props.onMenuItemClick}
          onSidebarMouseOver={props.onSidebarMouseOver}
          onSidebarMouseLeave={props.onSidebarMouseLeave}
          resetActiveIndex={props.resetActiveIndex}
          onMenuClick={props.onMenuClick}
        />

        <div className="layout-topbar-right">
          <ul className="layout-topbar-actions">
            <li className={classNames("topbar-item user-profile", {})}>
              <p className="font-bold">{userInfo}</p>
            </li>
            <li
              className={classNames("topbar-item user-profile", {
                "active-topmenuitem fadeInDown": props.topbarUserMenuActive,
              })}
            >
              <button className="p-link" style={{ cursor: "pointer", background: "gray" }} onClick={props.onTopbarUserMenuClick}>
                <img src={profile} alt="pp" />
              </button>
              <ul className="fadeInDown">
                <li onClick={() => setVisible(true)}>
                  <button className="p-link">
                    <span>Şifre Değiştir</span>
                  </button>
                </li>
                <li onClick={logout}>
                  <button className="p-link">
                    <span>Çıkış</span>
                  </button>
                </li>
              </ul>
            </li>
          </ul>
        </div>
      </div>

      <Modal card header="Şifre Değiştir" visible={visible} onHide={hideModal} onPress={handleChangePassword}>
        <Input
          name="currentPassword"
          label="Eski Şifre"
          errorText={submitted && !state.currentPassword && "Lütfen eski şifre giriniz"}
          value={state.currentPassword}
          onChange={onChange}
          placeholder="Eski Şifre"
          type="password"
        />
        <Input
          name="newPassword"
          label="Yeni Şifre"
          errorText={submitted && !state.newPassword && "Lütfen yeni şifre giriniz"}
          value={state.newPassword}
          onChange={onChange}
          placeholder="Yeni Şifre"
          type="password"
        />
        <Input
          name="reNewPassword"
          label="Yeni Şifre Tekrar"
          errorText={submitted && !state.reNewPassword && "Lütfen yeni şifre tekrar giriniz"}
          value={state.reNewPassword}
          onChange={onChange}
          placeholder="Yeni Şifre Tekrar"
          type="password"
        />
      </Modal>
    </div>
  );
};

export default AppTopbar;
