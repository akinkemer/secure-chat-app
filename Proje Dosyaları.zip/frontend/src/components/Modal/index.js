import React from "react";
import { Dialog } from "primereact/dialog";
import { Button } from "primereact/button";
import PropTypes from "prop-types";

export default function Modal(props) {
  const { visible, onHide, footer, children, header, onPress, label, card } = props;

  const _footer = () => {
    return (
      <div className="py-2">
        <Button label="Vazgeç" icon="pi pi-times" onClick={onHide} className="p-button-text" />
        <Button label={label} icon="pi pi-check" onClick={onPress} autoFocus />
      </div>
    );
  };

  return (
    <Dialog header={header} visible={visible} onHide={onHide} breakpoints={{ "960px": "75vw" }} style={{ width: "25vw" }} footer={footer ? footer : _footer}>
      <div className={card && "card"}>{children}</div>
    </Dialog>
  );
}

Modal.defaultProps = {
  label: "Onayla",
};

Modal.propTypes = {
  visible: PropTypes.bool,
  onHide: PropTypes.func,
  footer: PropTypes.any,
  children: PropTypes.any,
  header: PropTypes.string,
  onPress: PropTypes.func,
  label: PropTypes.string,
  card: PropTypes.bool,
};
