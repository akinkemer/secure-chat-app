import React from "react";
import { DataTable as DT } from "primereact/datatable";
import { Paginator } from "primereact/paginator";
import "./style.css";
import PropTypes from "prop-types";

export default function DataTable(props) {
  const passiveİtemClass = (item) => {
    return {
      "passive-item": item?.active !== 1,
    };
  };

  return (
    <>
      <DT emptyMessage="Kayıt Bulunamadı..." className="p-datatable-responsive-demo" value={props.data} {...props} rowClassName={passiveİtemClass}>
        {props.children}
      </DT>
      {props.paginationConfig && (
        <Paginator
          rows={props.paginationConfig.itemsPerPage}
          totalRecords={props.paginationConfig.totalRecords}
          first={props.paginationConfig.first}
          rowsPerPageOptions={[5, 10, 25]}
          onPageChange={props.onActivePageChange}
          template="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate="{totalRecords} kayıttan {first} - {last} arası gösteriliyor"
        />
      )}
    </>
  );
}

DataTable.propTypes = {
  rows: PropTypes.number,
  totalRecords: PropTypes.number,
  first: PropTypes.number,
  data: PropTypes.array,
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node)]),
  rowClass: PropTypes.string,
};
