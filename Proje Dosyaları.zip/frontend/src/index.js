import "react-app-polyfill/ie11";
import React, { lazy, Suspense } from "react";
import ReactDOM from "react-dom";
import { HashRouter, Route, Switch } from "react-router-dom";
import App from "./App";
import PrivateRoute from "./routes/PrivateRoute";
import PrimeReact from "primereact/api";
import { ToastContainer } from "react-toastify";
import { Provider as StoreProvider } from "react-redux";
import store from "./redux/store";
import "react-toastify/dist/ReactToastify.css";
import "react-datepicker/dist/react-datepicker.css";
import { SuspenseLoader } from "./components";

const Loader = (Component) => (props) =>
  (
    <Suspense fallback={<SuspenseLoader />}>
      <Component {...props} />
    </Suspense>
  );

const Login = Loader(lazy(() => import("./pages/Auth/Login")));
const ForgotPassword = Loader(lazy(() => import("./pages/Auth/ForgotPassword")));
const Register = Loader(lazy(() => import("./pages/Auth/Register")));
const NotFound = Loader(lazy(() => import("./pages/NotFound")));

PrimeReact.ripple = true;

ReactDOM.render(
  <StoreProvider store={store}>
    <ToastContainer
      theme="colored"
      position="top-right"
      autoClose={3000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      rtl={false}
      pauseOnFocusLoss
      draggable
    />
    <HashRouter>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route exact path="/login" component={Login} />
        <Route exact path="/forgotpassword" component={ForgotPassword} />
        <Route exact path="/register" component={Register} />
        <PrivateRoute component={App} />
        <Route component={NotFound} />
      </Switch>
    </HashRouter>
  </StoreProvider>,
  document.getElementById("root")
);
