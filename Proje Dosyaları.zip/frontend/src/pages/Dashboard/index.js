import React, {useState, useEffect, useRef} from "react";
import {over} from "stompjs";
import SockJS from "sockjs-client";
import Toast from "../../utils/Toast";
import {Input} from "../../components";
import {api} from "../../services/api";
import moment from "moment";
import {ScrollPanel} from 'primereact/scrollpanel';
import {Button} from "primereact/button"
import {ProgressSpinner} from "primereact/progressspinner"

let stompClient = null;

export default function Dashboard() {
    const user = JSON.parse(localStorage.getItem("user"));
    const baseURL = "http://localhost:39090/";

    const scrollRef = useRef(null);

    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState("");
    const [messages, setMessages] = useState([]);

    const [privateChats, setPrivateChats] = useState(new Map());
    const [publicChats, setPublicChats] = useState([]);

    const [tab, setTab] = useState("CHATROOM");
    const [userData, setUserData] = useState({
        username: '',
        receivername: '',
        connected: false,
        message: ''
    });

    useEffect(() => {
        connect()
        return () => {
            if (stompClient != null) {
                stompClient.disconnect();
            }
        }
    }, []);

    const connect = () => {
        let Sock = new SockJS(baseURL + 'ws');
        stompClient = over(Sock);
        stompClient.withCredentials = true
        stompClient.connect({}, onConnected, onError);
    }

    const onConnected = async () => {
        setUserData({...userData, "connected": true});
        stompClient.subscribe('/chatroom/public', onMessageReceived);
        const {data: messagesData = [], error: meesagesError} = await api.auth.getPublicMessages();
        if (meesagesError) {
            return Toast.error(meesagesError);
        }
        setMessages(messagesData);
        localStorage.setItem("publics", JSON.stringify(messagesData))

        setLoading(false);
    }

    const onMessageReceived = (payload) => {
        let _messages = JSON.parse(localStorage.getItem("publics"));
        _messages = [..._messages, JSON.parse(payload.body)];
        setMessages(_messages);
        localStorage.setItem("publics", JSON.stringify(_messages))
        scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }


    const stringToColour = (str) => {
        var hash = 0;
        for (var i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        var colour = '#';
        for (var i = 0; i < 3; i++) {
            var value = (hash >> (i * 8)) & 0xFF;
            colour += ('00' + value.toString(16)).substr(-2);
        }
        return colour;
    }

    const onError = (err) => {
        console.log(err);

    }

    const sendValue = () => {
        if (!message || message == "") {
            return;
        }
        let chatMessage;
        if (stompClient) {
            chatMessage = {
                fromUserId: user.id,
                fromId: user.id,
                sendAt: moment(new Date()).format('YYYY-MM-DDTHH:mm:ss'),
                message: message,
            };
            stompClient.send("/app/message", {}, JSON.stringify(chatMessage));
            setMessage("")
        }
    }


    const sentMessageTemplate = (m) => {
        return <div className="card text-right my-2 py-3" key={m.id}
                    style={{backgroundColor: stringToColour(m.fromName), marginLeft: 'auto'}}>
            <p className="py-0 my-0 font-bold text-sm">Ben</p>
            <p className="py-0 my-0">{m?.message}</p>
            <p className="py-0 my-0 text-sm font-italic">{moment(new Date(m.sendAt)).format("HH:mm")}</p>
        </div>
    }

    const receivedMessageTemplate = (m) => {
        return <div className="card text-left my-2 py-3" key={m.id}
                    style={{backgroundColor: stringToColour(m.fromName)}}>
            <p className="py-0 my-0 font-bold text-sm">{m.fromName}</p>
            <p className="py-0 my-0">{m?.message}</p>
            <p className="py-0 my-0 text-sm font-italic">{moment(new Date(m.sendAt)).format("HH:mm")}</p>

        </div>
    }
    const onChangeSetMessages = (e) => {
        let _value = e.target.value;
        setMessage(_value);
    }

    const enterKey = (e) => {
        if (e.key === "Enter") {
            sendValue()
        }
    };
    return (
        <div className="card mt-4">
            <div className="grid">
                {loading ? <ProgressSpinner/> : <>
                    <div className="col-12" style={{width: '100%', height: '28rem', overflowY: 'scroll'}}
                         ref={scrollRef}>
                        {
                            messages && messages.map(m => {
                                return (<div className="flex" key={m.id}>
                                    {
                                        m?.fromId == user.id ? sentMessageTemplate(m) : receivedMessageTemplate(m)
                                    }
                                </div>)
                            })
                        }
                    </div>
                    <div className="col-10">
                        <Input
                            name="message"
                            value={message}
                            onChange={onChangeSetMessages}
                            placeholder="Mesaj yazınız"
                            onKeyPress={enterKey}
                        />
                    </div>
                    <div className="col-2">
                        <Button
                            style={{width: "100%"}}
                            className="mt-3"
                            label="Gönder"
                            icon="pi pi-send"
                            onClick={sendValue}/>
                    </div>
                </>}
            </div>
        </div>
    )
}
