import React, {useState, useEffect, useRef} from "react";
import {over} from "stompjs";
import SockJS from "sockjs-client";
import {Input} from "../../components";
import {api} from "../../services/api";
import moment from "moment";
import {ScrollPanel} from 'primereact/scrollpanel';
import {Button} from "primereact/button"
import {MultiSelect} from 'primereact/multiselect';
import Toast from "../../utils/Toast";
import {ProgressSpinner} from "primereact/progressspinner"

export default function Group() {
    const user = JSON.parse(localStorage.getItem("user"));


    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState("");
    const [messages, setMessages] = useState([]);

    const [privateChats, setPrivateChats] = useState(new Map());
    const [publicChats, setPublicChats] = useState([]);
    const [selectedUsers, setSelectedUsers] = useState([]);
    const [userItems, setUserItems] = useState([]);

    useEffect(() => {
        let users = JSON.parse(localStorage.getItem("users"));
        let _userItems = users.map(u => {
            return {
                name: u.name + ' ' + u.surname,
                code: u.id
            }
        })
        setUserItems(_userItems);
        setLoading(false);
    }, []);

    const sendValue = async () => {
        if (!message || message == "") {
            return;
        }
        let request = {
            message,
            fromUserId: user.id,
            toBeSendUsers: selectedUsers.map(u => u.code)
        }
        const {data = {}, error} = await api.auth.sendGroupMessage(request);

        if (error) return Toast.error(error)

        Toast.success("Mesaj gönderme işlemi başarılı")
        setMessage("")
        setSelectedUsers([])
    }

    const onChangeSetMessages = (e) => {
        let _value = e.target.value;
        setMessage(_value);

    }


    const enterKey = (e) => {
        if (e.key === "Enter") {
            sendValue()
        }
    };
    return (
        <div className="card mt-4">
            <div className="grid">
                <div className="col-12">
                    <span className="p-float-label my-5" style={{width: '100%'}}>
                        <MultiSelect display="chip" optionLabel="name" style={{width: '100%'}}
                                     value={selectedUsers} options={userItems}
                                     onChange={(e) => setSelectedUsers(e.value)}/>
                        <label htmlFor="in">Mesaj Gönderilecek Kullanıcıları Seçiniz</label>
                    </span>
                </div>
            </div>
            <div className="grid">
                {loading ? <ProgressSpinner/> : <>
                    <div className="col-10">
                        <Input
                            name="message"
                            value={message}
                            onChange={onChangeSetMessages}
                            placeholder="Mesaj yazınız"
                            onKeyPress={enterKey}
                        />
                    </div>
                    <div className="col-2">
                        <Button
                            style={{width: "100%"}}
                            className="mt-3"
                            label="Gönder"
                            icon="pi pi-send"
                            onClick={sendValue}/>
                    </div>
                </>}
            </div>
        </div>
    )
}
