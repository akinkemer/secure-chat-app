import React, {useState} from "react";
import {InputText} from "primereact/inputtext";
import {Button} from "primereact/button";
import {useHistory} from "react-router-dom";
import classNames from "classnames";
import logo from "../../../assets/images/favicon.png";
import {api} from "../../../services/api";
import Toast from "../../../utils/Toast";
import {securePassword} from "../../../utils";
import Input from "../../../components/Input";
import Modal from "../../../components/Modal";
import {useSelector, useDispatch} from "react-redux";
import * as actions from "../../../redux/modules/users/users.action";


export default function Login() {
    const dispatch = useDispatch();
    //  const allBrand = useSelector((state) => state.brand.brandList);
    // const saveUser = (data) => dispatch(actions.saveUser(data));

    const emptyState = {
        currentPassword: "",
        newPassword: "",
        reNewPassword: "",
    };

    const [state, setState] = useState(emptyState);

    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const [submitted, setSubmitted] = useState(false);
    const [passwordSubmitted, setPasswordSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);
    const [visible, setVisible] = useState(false);

    const history = useHistory();

    const userId = JSON.parse(localStorage.getItem("user"))?.id;

    const onSubmit = async () => {
        setSubmitted(true);

        if (!username || !password) return;

        setLoading(true);

        const {data = {}, error} = await api.auth.login({username, password});

        setLoading(false);

        if (error) return Toast.error(error);

        localStorage.setItem("token", data?.token);
        localStorage.setItem("refreshToken", data?.refreshToken);

        const {data: optionsData = [], error: optionsError} = await api.auth.userInfo();

        if (optionsError) return;

        localStorage.setItem("user", JSON.stringify(optionsData));
        localStorage.setItem("users", optionsData?.users ? JSON.stringify(optionsData.users) : "[]");

        if (data?.isPasswordExpired) return setVisible(true);

        history.push("/public");
    };

    const hideModal = () => {
        localStorage.clear();
        setVisible(false);
    };

    const onChange = (e) => {
        setState({...state, [e.target.name]: e.target.value});
    };

    const handleChangePassword = async () => {
        setPasswordSubmitted(true);

        const {currentPassword, newPassword, reNewPassword} = state;

        if (!newPassword || !reNewPassword || !currentPassword) return;
        if (newPassword !== reNewPassword) return Toast.warning("Şifreler uyuşmuyor");
        if (newPassword.length < 8) return Toast.warning("Şifreniz en az 8 karakterden oluşmalıdır");
        if (securePassword(newPassword)) {
            return Toast.warning("Şifreniz en az bir büyük bir küçük harf, en az 1 rakam, en az bir özel karakter içermeli ve özel karakterler peş peşe girilemez.");
        }

        const params = {
            currentPassword: currentPassword,
            newPassword: newPassword,
        };
        const {data = {}, error} = await api.auth.changePassword({...params}, userId);

        if (error) return Toast.error(error);

        Toast.success(data);

        hideModal();
    };

    const enterKey = (e) => {
        if (e.key === "Enter") {
            onSubmit();
        }
    };

    return (
        <div className="login-body">
            <div className="login-wrapper">
                <div className="login-panel" style={{padding: 0}}>
                    <div onClick={() => history.push("/")} className="logo p-link" style={{margin: 0}}>
                        <img src={logo} alt="logo" style={{width: 150, height: 150}}/>
                    </div>
                    <span style={{fontSize: "1.6rem"}} className="text-primary font-bold flex text-center my-4">
                        SECURE CHAT APP
                    </span>

                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Kullanıcı Adı"
                        id="username2"
                        aria-describedby="username2-help"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        autoFocus
                        className={classNames({
                            "p-invalid": submitted && !username,
                        })}
                    />

                    {!username && submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            Kullanıcı adı boş olamaz
                        </small>
                    )}

                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Şifre"
                        id="password"
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e?.target?.value)}
                        required
                        className={classNames({
                            "p-invalid": submitted && !password,
                        })}
                    />
                    {!password && submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            Şifre boş olamaz
                        </small>
                    )}

                    <Button label="Giriş Yap" className="p-mt-3" onClick={onSubmit} loading={loading}/>
                    <span
                        onClick={() => history.push("/forgotpassword")}
                        style={{width: 243, color: "rgba(41, 50, 65, 0.6)"}}
                        className="flex justify-content-end font-bold forgot-password"
                    >
                        Şifremi Unuttum
                    </span>
                </div>
                <div className="text-align-center mb-5">
                    <h6>Hesabınız yok mu?</h6>
                    <h6 style={{color: "#464DF2"}}
                        onClick={() => history.push("/register")}
                        className="font-bold create-account">Hesap Oluştur</h6>
                </div>
                <div className="login-footer">
                    <h6>Ⓒ Secure Chat App</h6>
                </div>
            </div>

            <Modal card header="Şifre Değiştir" visible={visible} onHide={hideModal} onPress={handleChangePassword}>
                <span className="font-bold text-pink-500 py-5"> Şifrenizin 6 aylık süresi dolmuştur. Devam edebilmek
                    için lütfen şifrenizi değiştirin !</span>
                <Input
                    name="currentPassword"
                    label="Eski Şifre"
                    errorText={passwordSubmitted && !state.currentPassword && "Lütfen eski şifre giriniz"}
                    value={state.currentPassword}
                    onChange={onChange}
                    placeholder="Eski Şifre"
                    type="password"
                />
                <Input
                    name="newPassword"
                    label="Yeni Şifre"
                    errorText={passwordSubmitted && !state.newPassword && "Lütfen yeni şifre giriniz"}
                    value={state.newPassword}
                    onChange={onChange}
                    placeholder="Yeni Şifre"
                    type="password"
                />
                <Input
                    name="reNewPassword"
                    label="Yeni Şifre Tekrar"
                    errorText={passwordSubmitted && !state.reNewPassword && "Lütfen yeni şifre tekrar giriniz"}
                    value={state.reNewPassword}
                    onChange={onChange}
                    placeholder="Yeni Şifre Tekrar"
                    type="password"
                />
            </Modal>
        </div>
    );
}
