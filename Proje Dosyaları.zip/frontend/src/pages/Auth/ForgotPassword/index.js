import React, { useState } from "react";
import { InputText } from "primereact/inputtext";
import { Button } from "primereact/button";
import { useHistory, Redirect } from "react-router-dom";
import classNames from "classnames";
import logo from "../../../assets/images/favicon.png";
import { api } from "../../../services/api";
import Toast from "../../../utils/Toast";
import OtpInput from "react-otp-input";
import { securePassword } from "../../../utils";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");

  const [newPassword, setNewPassword] = useState("");
  const [reNewPassword, setReNewPassword] = useState("");

  const [showOTP, setShowOTP] = useState(false);
  const [otpCode, setOtpCode] = useState("");

  const [submitGetOTPCode, setSubmitGetOTPCode] = useState(false);
  const [submitResetPassword, setSubmitResetPassword] = useState(false);

  const [loading, setLoading] = useState(false);

  const history = useHistory();

  const isAuthenticated = localStorage.getItem("token");

  if (isAuthenticated) return <Redirect to={"/dashboard"} />;

  const getOTPCode = async () => {
    setOtpCode("");
    setNewPassword("");
    setReNewPassword("");
    setSubmitResetPassword(false);

    setSubmitGetOTPCode(true);

    if (!email) return;

    setLoading(true);

    const { data = {}, error } = await api.auth.forgot({ email });

    setLoading(false);

    if (error) return Toast.error(error);

    Toast.success(data?.message);

    setShowOTP(true);
  };

  const handleResetPassword = async () => {
    setSubmitResetPassword(true);

    if (otpCode?.length !== 4) return Toast.warning("Doğrulama Kodu 4 karakter olmalıdır");
    if (!newPassword || !reNewPassword) return;
    if (newPassword !== reNewPassword) return Toast.warning("Şifreler uyuşmuyor");
    if (newPassword.length < 8) return Toast.warning("Şifreniz en az 8 karakterden oluşmalıdır");
    if (securePassword(newPassword)) {
      return Toast.warning("Şifreniz en az bir büyük bir küçük harf, en az 1 rakam, en az bir özel karakter içermeli ve özel karakterler peş peşe girilemez.");
    }

    setLoading(true);

    const params = { newPassword, passwordResetAuthCode: otpCode };

    const { data = {}, error } = await api.auth.reset({ ...params });

    setLoading(false);

    if (error) return Toast.error(error);

    Toast.success(data?.message);

    history.push("/login");
  };

  const enterKey = (e) => {
    if (e.key === "Enter") {
      getOTPCode();
    }
  };

  return (
    <div className="login-body">
      <div className="login-wrapper">
        <div className="login-panel" style={{ padding: 0 }}>
          <div onClick={() => history.push("/")} className="logo p-link" style={{ margin: 0 }}>
            <img src={logo} alt="logo" style={{ width: 150, height: 150 }} />
          </div>
          <span style={{ fontSize: "1.6rem" }} className="text-primary font-bold flex text-center my-4">
            SECURE CHAT APP
          </span>
          {!showOTP && (
            <>
              <InputText
                onKeyPress={enterKey}
                placeholder="E-Posta"
                id="email"
                aria-describedby="email-help"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoFocus
                className={classNames({
                  "p-invalid": submitGetOTPCode && !email,
                })}
              />

              {!email && submitGetOTPCode && (
                <small className="p-error" style={{ marginBlockEnd: 15 }}>
                  E-Posta boş olamaz
                </small>
              )}

              <Button label="Şifre Al" className="p-mt-3" onClick={getOTPCode} loading={loading} />
              <span
                onClick={() => history.push("/login")}
                style={{ width: 243, color: "rgba(41, 50, 65, 0.6)" }}
                className="flex justify-content-end font-bold forgot-password"
              >
                Giriş Ekranına Dön
              </span>
            </>
          )}

          {showOTP && (
            <>
              <div className="card pl-6 pr-6 pb-0">
                <div className="font-bold pb-2">Doğrulama Kodu</div>
                <OtpInput
                  value={otpCode}
                  onChange={(e) => setOtpCode(e)}
                  numInputs={4}
                  separator={<span style={{ width: "8px" }}></span>}
                  isInputNum={true}
                  shouldAutoFocus={true}
                  inputStyle={{
                    border: "1px solid transparent",
                    borderRadius: "8px",
                    width: "55px",
                    height: "55px",
                    fontSize: "14px",
                    color: "#000",
                    fontWeight: "400",
                    caretColor: "blue",
                    backgroundColor: "#fff",
                    border: submitResetPassword && !otpCode ? "1px solid red" : "1px solid #CFD3DB",
                    marginBottom: "35px",
                    marginTop: "20px",
                  }}
                  focusStyle={{
                    border: submitResetPassword && !otpCode ? "1px solid red" : "1px solid #464DF2",
                    outline: "none",
                  }}
                />
              </div>
              <InputText
                placeholder="Yeni Şifre"
                id="newPassword"
                type="password"
                aria-describedby="newPassword-help"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                required
                autoFocus
                className={classNames({
                  "p-invalid": submitResetPassword && !email,
                })}
              />

              {!newPassword && submitResetPassword && (
                <small className="p-error" style={{ marginBlockEnd: 15 }}>
                  Yeni Şifre Giriniz
                </small>
              )}

              <InputText
                placeholder="Yeni Şifre Tekrar"
                id="reNewPassword"
                type="password"
                aria-describedby="reNewPassword-help"
                value={reNewPassword}
                onChange={(e) => setReNewPassword(e.target.value)}
                required
                autoFocus
                className={classNames({
                  "p-invalid": (submitResetPassword && !reNewPassword) || newPassword !== reNewPassword,
                })}
              />

              {!reNewPassword && submitResetPassword && (
                <small className="p-error" style={{ marginBlockEnd: 15 }}>
                  Yeni Şifre Tekrar giriniz
                </small>
              )}

              <Button label="Gönder" className="p-mt-3" onClick={handleResetPassword} loading={loading} />
              <span
                onClick={() => setShowOTP(false)}
                style={{ width: 243, color: "rgba(41, 50, 65, 0.6)" }}
                className="flex justify-content-end font-bold forgot-password"
              >
                E-Posta değiştir
              </span>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
