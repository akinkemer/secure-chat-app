import React, {useState} from "react";
import {InputText} from "primereact/inputtext";
import {Button} from "primereact/button";
import {useHistory} from "react-router-dom";
import classNames from "classnames";
import logo from "../../../assets/images/favicon.png";
import {api} from "../../../services/api";
import Toast from "../../../utils/Toast";
import {securePassword} from "../../../utils";
import Input from "../../../components/Input";
import Modal from "../../../components/Modal";

export default function Register() {

    const [name, setName] = useState("");
    const [surname, setSurname] = useState("");
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");

    const [submitted, setSubmitted] = useState(false);
    const [passwordSubmitted, setPasswordSubmitted] = useState(false);
    const [loading, setLoading] = useState(false);
    const [visible, setVisible] = useState(false);
    const [passwordError, setPasswordError] = useState(null);

    const history = useHistory();

    const onChange = (e) => {
        setState({...state, [e.target.name]: e.target.value});
    };

    const onSubmit = async () => {
        setSubmitted(true);

        if (!password || password.length < 8) {
            setPasswordError("Şifreniz en az 8 karakterden oluşmalıdır")
            return;
        }
        else if (securePassword(password)) {
            setPasswordError("Şifreniz en az bir büyük bir küçük harf," +
                " en az 1 rakam, en az bir özel karakter içermeli " +
                "ve özel karakterler peş peşe girilmemelidir.")
            return;
        } else {
            setPasswordError(null)
        }

        if (!username | !name || !surname) return;

        setLoading(true);

        const {data = {}, error} = await api.auth.register({email:username, password, name, surname});

        setLoading(false);

        if (error) return Toast.error(error);

        Toast.success("Kayıt olma işlemi başarılı");
        history.push("/login");
    };


    const enterKey = (e) => {
        if (e.key === "Enter") {
            onSubmit();
        }
    };

    return (
        <div className="login-body">
            <div className="login-wrapper">
                <div className="login-panel" style={{padding: 0}}>
                    <div onClick={() => history.push("/")} className="logo p-link" style={{ margin: 0 }}>
                        <img src={logo} alt="logo" style={{ width: 100, height: 100 }} />
                        <span style={{ fontSize: "1.6rem" }} className="text-primary font-bold flex text-center my-4">
                            HESAP OLUŞTUR
                        </span>
                    </div>

                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Ad"
                        id="name"
                        aria-describedby="name-help"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                        autoFocus
                        className={classNames({
                            "p-invalid": submitted && !name,
                        })}
                    />

                    {!name && submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            Ad kısmı boş olamaz
                        </small>
                    )}

                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Soyad"
                        id="surname"
                        aria-describedby="surname-help"
                        value={surname}
                        onChange={(e) => setSurname(e.target.value)}
                        required
                        autoFocus
                        className={classNames({
                            "p-invalid": submitted && !surname,
                        })}
                    />

                    {!surname && submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            Soyad kısmı boş olamaz
                        </small>
                    )}
                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Email"
                        id="username2"
                        aria-describedby="username2-help"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                        autoFocus
                        className={classNames({
                            "p-invalid": submitted && !username,
                        })}
                    />

                    {!username && submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            Kullanıcı adı boş olamaz
                        </small>
                    )}

                    <InputText
                        onKeyPress={enterKey}
                        placeholder="Şifre"
                        id="password"
                        type="password"
                        value={password}
                        autoComplete="new-password"
                        onChange={(e) => setPassword(e?.target?.value)}
                        required
                        className={classNames({
                            "p-invalid": submitted && !password,
                        })}
                    />
                    {submitted && (
                        <small className="p-error" style={{marginBlockEnd: 15}}>
                            {passwordError}
                        </small>
                    )}

                    <Button label="Kayıt Ol" className="mt-3" onClick={onSubmit} loading={loading}/>
                </div>
                <div className="login-footer">
                    <h6>Ⓒ Secure Chat App</h6>
                </div>
            </div>

        </div>
    );
}
