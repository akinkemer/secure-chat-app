import React, {useEffect, useRef, useState} from "react";
import {over} from "stompjs";
import SockJS from "sockjs-client";
import Toast from "../../utils/Toast";
import {Input} from "../../components";
import {api} from "../../services/api";
import moment from "moment";
import {Button} from "primereact/button"
import {ProgressSpinner} from "primereact/progressspinner"
import {useParams} from 'react-router-dom';
import {encrypt, decrypt, createKeyPair} from '../../utils/crypto'

let stompClient = null;

export default function Private() {
    const user = JSON.parse(localStorage.getItem("user"));
    const baseURL = "http://localhost:39090/";
    const scrollRef = useRef(null);

    const {id} = useParams();

    const [stompConnected, setStompConnected] = useState(false);

    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState("");
    const [description, setDescription] = useState("");
    const [messages, setMessages] = useState([]);

    const [p, setP] = useState(null);
    const [alfa, setAlfa] = useState(null);
    const [ownPublicKey, setOwnPublicKey] = useState(null);
    const [ownPricateKey, setOwnPrivateKey] = useState(null);
    const [receiverPublicKey, setReceiverPublicKey] = useState(null);
    const [certificate, setCertificate] = useState(null);
    const [receiverConnectionEstablished, setReceiverConnectionEstablished] = useState(false);

    useEffect(() => {
        connect()
        localStorage.setItem("loading", true);
        localStorage.setItem("isConnected", false)
        return () => {
            if (stompClient != null && stompClient.connected) {
                stompClient.disconnect();
            }
            localStorage.removeItem("privates");
            localStorage.removeItem("loading");
            localStorage.removeItem("public_key")
            localStorage.removeItem("private_key")
            localStorage.setItem("isConnected", false);
            localStorage.setItem("loading", true);
            setReceiverConnectionEstablished(false);
            setLoading(true);
        }
    }, [id]);

    useEffect(() => {
        let timer;

        function repeatingFunc() {
            if (stompClient && localStorage.getItem("isConnected") == 'false') {
                setDescription("Kullanıcıya bağlanılıyor...")
                const request = {
                    fromUserId: user.id,
                    toUserId: id,
                    message: JSON.stringify(certificate),
                    isCertificate: true,
                    isConnected: localStorage.getItem("loading") == 'false'
                };
                if (certificate) {
                    stompClient.send("/app/private-message", {}, JSON.stringify(request));
                }
                timer = setTimeout(repeatingFunc, 2000);
            }
        }

        repeatingFunc()

        return () => {
            clearTimeout(timer)
        }

    }, [certificate, receiverConnectionEstablished]);


    const connect = () => {
        let Sock = new SockJS(baseURL + 'ws');
        stompClient = over(Sock);
        stompClient.withCredentials = true
        stompClient.connect({}, onConnected, onError);
        localStorage.setItem("loading", true)
        setStompConnected(true);
    }

    const onConnected = async () => {
        stompClient.subscribe('/user/' + user.id + '/private', onMessageReceived);
        const {data: messagesData = [], error: meesagesError} = await api.auth.getPrivateMessages(user.id, id);
        if (meesagesError) {
            return Toast.error(meesagesError);
        }
        setMessages(messagesData);
        localStorage.setItem("privates", JSON.stringify(messagesData))

        let ownPublic = await createKeyPair();
        setOwnPublicKey(ownPublic);

        const {data: certData = [], error: certError} = await api.auth.getCertificate({
            userId: user.id,
            publicKey: ownPublic
        });

        setCertificate(certData);
        localStorage.setItem("certificate", JSON.stringify(certData))

        if (stompClient) {
            const request = {
                fromUserId: user.id,
                toUserId: id,
                message: JSON.stringify(certData),
                isCertificate: true,
                isConnected: false
            };
            stompClient.send("/app/private-message", {}, JSON.stringify(request));
        }
    }

    const onMessageReceived = async (payload) => {
        const receivedMessage = JSON.parse(payload.body);

        setReceiverConnectionEstablished(receivedMessage.isConnected)
        localStorage.setItem("isConnected", receivedMessage.isConnected)

        if (receivedMessage.isCertificate) {
            if (!receivedMessage.isConnected) {
                if (stompClient) {
                    const request = {
                        fromUserId: user.id,
                        toUserId: id,
                        message: localStorage.getItem("certificate"),
                        isCertificate: true,
                        isConnected: true
                    };
                    if (localStorage.getItem("certificate")) {
                        setTimeout(() => stompClient.send("/app/private-message", {}, JSON.stringify(request)), 1000)
                    }
                }
            }

            if (localStorage.getItem("loading") == 'true') {
                const _certificate = JSON.parse(receivedMessage.message);
                const {data: certData = [], error: certError} = await api.auth.verifyCertificate(_certificate);
                if (certError) return Toast.error(certError)
                localStorage.setItem("rec_cert", JSON.stringify(_certificate))
                setLoading(false)
                localStorage.setItem("loading", false)
                localStorage.setItem("isConnected", true)
                setReceiverPublicKey(_certificate.publicKey)
                localStorage.setItem("receiver_key", _certificate.publicKey)

                if (stompClient && !localStorage.getItem("isConnected") == 'true') {
                    const request = {
                        fromUserId: user.id,
                        toUserId: id,
                        message: localStorage.getItem("certificate"),
                        isCertificate: true,
                        isConnected: true
                    };
                    if (localStorage.getItem("certificate")) {
                        setTimeout(() => stompClient.send("/app/private-message", {}, JSON.stringify(request)), 1000)
                    }
                }
            }
        } else {
            if (localStorage.getItem("loading") == 'false') {
                let _messages = JSON.parse(localStorage.getItem("privates"));
                let cert = JSON.parse(localStorage.getItem("certificate"))
                let e = cert.publicKey.split(' ')[0];
                let n = cert.publicKey.split(' ')[1]
                let newObj = receivedMessage;
                newObj.message = await decrypt(receivedMessage.message, e, n);
                _messages = [..._messages, newObj];
                setMessages(_messages);
                localStorage.setItem("privates", JSON.stringify(_messages))
                scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
            }
        }
    }

    const scrollDown = () => {
        setTimeout(() => {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }, 150)
    }

    const stringToColour = (str) => {
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            hash = str.charCodeAt(i) + ((hash << 5) - hash);
        }
        let colour = '#';
        for (let i = 0; i < 3; i++) {
            let value = (hash >> (i * 8)) & 0xFF;
            colour += ('00' + value.toString(16)).substr(-2);
        }
        return colour;
    }

    const onError = (err) => {
        console.log(err);
    }


    const sendValue = async () => {
        if (!message || message == "") {
            return;
        }
        let _message = await encrypt(message, localStorage.getItem("n"), localStorage.getItem("d"))
        let chatMessage;
        if (stompClient) {
            chatMessage = {
                fromName: user.name + " " + user.surname,
                fromUserId: user.id,
                fromId: user.id,
                toUserId: id,
                sendAt: moment(new Date()).format('YYYY-MM-DDTHH:mm:ss'),
                message: _message,
                isConnected: localStorage.getItem("isConnected")
            };
            stompClient.send("/app/private-message", {}, JSON.stringify(chatMessage));

            let _messages = JSON.parse(localStorage.getItem("privates"));
            chatMessage.message = message;
            _messages = [..._messages, chatMessage];
            setMessages(_messages);
            localStorage.setItem("privates", JSON.stringify(_messages))
            scrollDown()
            setMessage("")
        }
    }

    const sentMessageTemplate = (m) => {
        return <div className="card text-right my-2 py-3" key={m.id}
                    style={{backgroundColor: stringToColour(m.fromName), marginLeft: 'auto'}}>
            <p className="py-0 my-0 font-bold text-sm">Ben</p>
            <p className="py-0 my-0">{m?.message}</p>
            <p className="py-0 my-0 text-sm font-italic">{moment(new Date(m.sendAt)).format("HH:mm")}</p>
        </div>
    }

    const receivedMessageTemplate = (m) => {
        return <div className="card text-left my-2 py-3" key={m.id}
                    style={{backgroundColor: stringToColour(m.fromName)}}>
            <p className="py-0 my-0 font-bold text-sm">{m.fromName}</p>
            <p className="py-0 my-0">{m?.message}</p>
            <p className="py-0 my-0 text-sm font-italic">{moment(new Date(m.sendAt)).format("HH:mm")}</p>

        </div>
    }

    const onChangeSetMessages = (e) => {
        let _value = e.target.value;
        setMessage(_value);
    }

    const enterKey = (e) => {
        if (e.key === "Enter") {
            sendValue()
        }
    };
    return (<div className="card mt-4">
        <div className="grid">
            {localStorage.getItem("loading") == 'true' ?
                <div className="col-12 text-center">
                    <h3 className="text-center my-3">{description}</h3>
                    <ProgressSpinner/>
                </div>
                : <>
                    <div className="col-12" style={{width: '100%', height: '31rem', overflowY: 'scroll'}}
                         ref={scrollRef}>
                        {messages && messages.map(m => {
                            return (<div className="flex" key={m.id}>
                                {m?.fromId == user.id ? sentMessageTemplate(m) : receivedMessageTemplate(m)}
                            </div>)
                        })}
                    </div>
                    <div className="col-10">
                        <Input
                            name="message"
                            value={message}
                            onChange={onChangeSetMessages}
                            placeholder="Mesaj yazınız"
                            onKeyPress={enterKey}
                        />
                    </div>
                    <div className="col-2">
                        <Button
                            style={{width: "100%"}}
                            className="mt-3"
                            label="Gönder"
                            icon="pi pi-send"
                            onClick={sendValue}/>
                    </div>
                </>}
        </div>
    </div>)
}
