import { auth } from "./auth";

/**
 * All api calls
 *
 * @class api
 */
class api {

  /**
   *
   * Auth
   * @static
   * @memberof api
   */
  static auth = auth;
}

export { api };
