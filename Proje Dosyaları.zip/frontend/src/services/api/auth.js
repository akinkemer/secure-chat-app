import request from "./request";

import * as paths from "./paths";

const certificateURL = "/certificate";
const verifyCertificateURL = "/verify";

class auth {
    /**
     *
     * login
     *
     * @static
     * @memberof auth
     */
    static login = async (params) => {
        return await request.post(paths.login, params);
    };
    /**
     *
     * register
     *
     * @static
     * @memberof auth
     */
    static register = async (params) => {
        return await request.post(paths.register, params);
    };
    /**
     *
     * logout
     *
     * @static
     * @memberof auth
     */
    static logout = async (params) => {
        return await request.post(paths.logout, params);
    };
    /**
     *
     * userinfo
     *
     * @static
     * @memberof auth
     */
    static userInfo = async (params) => {
        return await request.get(paths.own, params);
    };

    /**
     *
     * forgot password
     *
     * @static
     * @memberof auth
     */
    static forgot = async (params) => {
        return await request.post(paths.forgot, params);
    };
    /**
     *
     * reset password
     *
     * @static
     * @memberof auth
     */
    static reset = async (params) => {
        return await request.post(paths.reset, params);
    };

    /**
     *
     * change password
     *
     * @static
     * @memberof auth
     */
    static changePassword = async (params, id) => {
        return await request.post(paths.changePassword + id, params);
    };

    /**
     *
     * get public messages
     *
     * @static
     * @memberof auth
     */
    static getPublicMessages = async () => {
        return await request.get(paths.getPublicMessages);
    };
    /**
     *
     * get private messages
     *
     * @static
     * @memberof auth
     */
    static getPrivateMessages = async (from, to) => {
        return await request.get(paths.getPrivateMessages + "/" + from + "/" + to);
    };
    /**
     *
     * send group message
     *
     * @static
     * @memberof auth
     */
    static sendGroupMessage = async (requestBody) => {
        return await request.post(paths.sendGroupMessage, requestBody);
    };

    /**
     *
     * get p and alfa
     *
     * @static
     * @memberof auth
     */
    static getPAndAlfa = async (requestBody) => {
        return await request.post(paths.getPAndAlfa, requestBody);
    };

    /**
     *
     * get certificate
     *
     * @static
     * @memberof auth
     */
    static getCertificate = async (requestBody) => {
        return await request.customPost(certificateURL, requestBody);
    };

    /**
     *
     * verify certificate
     *
     * @static
     * @memberof auth
     */
    static verifyCertificate = async (requestBody) => {
        return await request.customPost(verifyCertificateURL, requestBody);
    };
}

export {auth};
