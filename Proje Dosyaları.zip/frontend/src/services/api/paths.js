//paths

export const login = "api/auth/login";
export const register = "api/auth/register";
export const forgot = "api/public/forgotPassword";
export const reset = "api/public/resetPassword";
export const changePassword = "api/changePassword/";
export const logout = "api/auth/logout";
export const refresh = "api/auth/refreshtoken";
export const own = "api/own";


//user
export const userList = "api/userList";
export const deleteUser = "api/userDelete/";
export const updateUser = "api/userUpdate";
export const userIsActive = "api/user/active/";

export const roleList = "api/userRoles";
export const locations = "api/public/locations";

export const getPublicMessages = "api/messages";
export const getPAndAlfa = "api/messages/pAndAlfa";
export const getPrivateMessages = "api/messages/private";
export const sendGroupMessage = "api/messages/group";

