import React, {Suspense, lazy} from "react";
import {SuspenseLoader} from "../components/";

const Loader = (Component) => (props) =>
    (
        <Suspense fallback={<SuspenseLoader/>}>
            <Component {...props} />
        </Suspense>
    );

const Dashboard = Loader(lazy(() => import("../pages/Dashboard")));
const Private = Loader(lazy(() => import("../pages/Private")));
const Group = Loader(lazy(() => import("../pages/Group")));

export const routers = [
    {
        path: "/public",
        component: Dashboard,
        label: "Public Chat",
    },
    {
        path: "/private/:id",
        component: Private,
        label: "Private Chat",
    },
    {
        path: "/group",
        component: Group,
        label: "Group Chat",
    }
];
