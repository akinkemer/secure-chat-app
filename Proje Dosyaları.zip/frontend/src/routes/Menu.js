import {MdPublic, MdMailOutline,MdOutlineGroup} from "react-icons/md";

const SIZE = 25;
export default function Menu() {

    let users = localStorage.getItem("users")
    const menuList = users == null ? [] : JSON.parse(users);
    let menu = []

    menu.push(
        {
            label: "Public Chat",
            icon: <MdPublic size={SIZE}/>,
            to: "/public",
        });

    // menu.push(
    //     {
    //         label: "Group Chat",
    //         icon: <MdOutlineGroup size={SIZE}/>,
    //         to: "/group",
    //     });

    menuList.forEach(m => {
        menu.push({
            label: `${m.name} ${m.surname}`,
            icon: <MdMailOutline size={SIZE}/>,
            to: `/private/${m.id}`,
            private: true

        })
    })

    return menu;
}
