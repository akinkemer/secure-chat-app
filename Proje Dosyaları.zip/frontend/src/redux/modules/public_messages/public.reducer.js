import * as actionTypes from "./public.type";

const initialState = {
    messageList: [],
};

const reducer = (state = initialState, {type, payload, ...params}) => {
    switch (type) {
        case actionTypes.SAVE_MESSAGE:
            return {...state, messageList: [...message, payload]};
        default:
            return state;
    }
};

export default reducer;
