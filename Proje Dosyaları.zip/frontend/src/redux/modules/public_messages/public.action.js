import * as actionTypes from "./public.type";

export function saveMessage(data) {
    return {
        type: actionTypes.SAVE_MESSAGE,
        payload: data,
    };
}
