import { combineReducers } from "redux";

import user from "./user/user.reducer";
import users from "./users/users.reducer";
import publics from "./public_messages/public.reducer";

const rootReducer = combineReducers({
  user,
  users,
  publics
});

export default rootReducer;
