import * as actionTypes from "./users.type";

export function saveUser(data) {
    return {
        type: actionTypes.SAVE_USER,
        payload: data,
    };
}
