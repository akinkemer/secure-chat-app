import * as actionTypes from "./user.type";

export function saveUser(data) {
  return {
    type: actionTypes.SAVE_USER,
    payload: data,
  };
}
