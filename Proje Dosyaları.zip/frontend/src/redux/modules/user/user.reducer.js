import * as actionTypes from "./user.type";

const initialState = {
  userList: [],
};

const reducer = (state = initialState, { type, payload, userList, ...params }) => {
  switch (type) {
    case actionTypes.SAVE_USER:
      return { ...state, userList: payload };
    default:
      return state;
  }
};

export default reducer;
