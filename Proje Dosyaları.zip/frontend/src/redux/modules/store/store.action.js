import * as actionTypes from "./store.type";

export function saveStore(data) {
  return {
    type: actionTypes.SAVE_STORE,
    payload: data,
  };
}
