import * as actionTypes from "./store.type";

const initialState = {
  storeList: [],
};

const reducer = (state = initialState, { type, payload, storeList, ...params }) => {
  switch (type) {
    case actionTypes.SAVE_STORE:
      return { ...state, storeList: payload };
    default:
      return state;
  }
};

export default reducer;
