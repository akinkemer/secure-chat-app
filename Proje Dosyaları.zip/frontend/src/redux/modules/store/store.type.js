export const SAVE_STORE = "SAVE_STORE";
