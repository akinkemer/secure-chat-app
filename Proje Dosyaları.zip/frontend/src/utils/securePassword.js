const securePassword = (password) => {
  let error = false;

  if (password.search(/[a-z]/) == -1) {
    error = true;
  }
  if (password.search(/[A-Z]/) == -1) {
    error = true;
  }
  if (password.search(/[0-9]/) == -1) {
    error = true;
  }
  if (password.search(/\W/) == -1) {
    error = true;
  }
  if (password.search(/^(?!.*([\W])\1)/) == -1) {
    error = true;
  }
  return error;
};

export { securePassword };
