import sha256 from 'crypto-js/sha256';
import Base64 from 'crypto-js/enc-base64';
import aes from 'crypto-js/aes';
import RSA from './RSA'

//hash 44

const hash = (plain_text) => {
    return Base64.stringify(sha256(plain_text));
}

const createKeyPair = async () => {
    const keys = RSA.generate(64);
    let publicKey = keys.e + ' ' + keys.n;
    localStorage.setItem("d", keys.d);
    localStorage.setItem("n", keys.n);
    localStorage.setItem("e", keys.e);
    return publicKey;
}

const rsaDec = async (key, ciphertext) => {

}

const rsaEnc = async (key, message) => {

}


const createPublicKey = (e_n) => {

}

const encrypt = async (plain_text, n, e) => {

    const message = "asdsa";

    const keys = RSA.generate(250);

    console.log('Keys');
    console.log('n:', keys.n.toString());
    console.log('d:', keys.d.toString());
    console.log('e:', keys.e.toString());

    const _encoded_message = RSA.encode(message);
    const _encrypted_message = RSA.encrypt(_encoded_message, keys.n, keys.d);
    const _decrypted_message = RSA.decrypt(_encrypted_message, keys.e, keys.n);
    const _decoded_message = RSA.decode(_decrypted_message);

    console.log('Message:', message);
    console.log('Encoded:', _encoded_message.toString());
    console.log('Encrypted:', _encrypted_message.toString());
    console.log('Decrypted:', _decrypted_message.toString());
    console.log('Decoded:', _decoded_message.toString());
    console.log();
    console.log('Correct?', message === _decoded_message);

    const encoded_message = RSA.encode(plain_text);
    console.log("encoded_message", encoded_message)
    console.log("n", n)
    console.log("e", e)

    const encrypted_message = RSA.encrypt(encoded_message, BigInt(n), BigInt(e));
    return encrypted_message;
}

const decrypt = async (cipher_text, d, n) => {
    console.log("d " + d)
    console.log("n " + n)

    const decrypted_message = RSA.decrypt(cipher_text, BigInt(d), BigInt(n));
    console.log("decrypted_message", decrypted_message)
    const decoded_message = RSA.decode(decrypted_message);
    console.log("decoded_message", decoded_message)
    return decoded_message;
}

export {encrypt, decrypt, createKeyPair}
