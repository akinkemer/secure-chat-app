module.exports = {
  printWidth: 170,
};
