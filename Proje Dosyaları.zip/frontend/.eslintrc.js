module.exports = {
    parser: "@babel/eslint-parser",
  };