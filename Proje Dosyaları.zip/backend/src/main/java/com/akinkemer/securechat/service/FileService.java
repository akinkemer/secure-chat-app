package com.akinkemer.securechat.service;

import com.akinkemer.securechat.exception.GeneralException;
import com.akinkemer.securechat.model.entity.Document;
import com.akinkemer.securechat.repository.DocumentRepository;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import javax.xml.bind.DatatypeConverter;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.UUID;

@Getter
@Service
@Slf4j
@RequiredArgsConstructor
public class FileService {

    @Value("${app.file.path.base}")
    private String FILE_PATH_BASE;

    @Value("${app.file.url.base}")
    private String FILE_URL_BASE;

    private final DocumentRepository documentRepository;

    private String getDate() {
        return OffsetDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMM"));
    }

    @SneakyThrows
    private Path createOrGetFolder() {
        Path filePath = Paths.get(FILE_PATH_BASE + "/" + getDate());

        if (!Files.exists(filePath)) {
            Files.createDirectory(filePath);
        }

        return filePath;
    }

    @SneakyThrows
    @Transactional
    public Document save(MultipartFile file) {
        Path filePath = createOrGetFolder();

        String publicFileName = "";
        String originalFilename = file.getOriginalFilename();
        if (originalFilename != null) {
            publicFileName = UUID.randomUUID().toString() + originalFilename.substring(originalFilename.lastIndexOf("."));
        }

        Files.copy(file.getInputStream(), filePath.resolve(publicFileName));

        Document document = new Document();
        document.setBaseUrl(FILE_URL_BASE);
        document.setBasePath(FILE_PATH_BASE);
        document.setDynamicPath("/" + getDate() + "/" + publicFileName);
        document.setPublicId(publicFileName);
        document.setName(file.getOriginalFilename());

        return document;
    }

    @SneakyThrows
    @Transactional
    public Document saveBase64(String encodedImage, String fileType) {
        Path filePath = createOrGetFolder();
        String uuid = UUID.randomUUID().toString();
        String publicFileName = uuid + "." + fileType.replace(".","");

        byte[] result = DatatypeConverter.parseBase64Binary(encodedImage);

        try {
            try (OutputStream stream = new FileOutputStream(filePath + "/" + publicFileName)) {
                stream.write(result);
            }

            Document document = new Document();
            document.setBaseUrl(FILE_URL_BASE);
            document.setBasePath(FILE_PATH_BASE);
            document.setDynamicPath("/" + getDate() + "/" + publicFileName);
            document.setPublicId(publicFileName);

            return document;
        } catch (Exception e) {
            e.printStackTrace();
            throw new GeneralException("Dosya yüklenemedi!");
        }
    }

    public ResponseEntity downloadFile(String dynamicPath) {
        String filePath = checkIfExistAndBuildFilePathByDynamicPath(dynamicPath);
        
        File file = new File(filePath);

        InputStreamResource resource = null;
        try {
            resource = new InputStreamResource(new FileInputStream(file));
        } catch (IOException e) {
            e.printStackTrace();
        }

        HttpHeaders headers = new HttpHeaders();
        headers.add("Cache-Control", "no-cache, no-store, must-revalidate");
        headers.add("Pragma", "no-cache");
        headers.add("Expires", "0");
        headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment;filename=\"" + dynamicPath + "\"");

        return ResponseEntity.ok()
                .headers(headers)
                .contentLength(file.length())
                .contentType(MediaType.APPLICATION_OCTET_STREAM)
                .body(resource);
    }

    private String checkIfExistAndBuildFilePathByDynamicPath(String dynamicPath) {
        if (!StringUtils.hasText(dynamicPath)) {
            throw new GeneralException("Invalid document path");
        }

        Optional<Document> optionalDocument = documentRepository.getDocumentByDynamicPath(dynamicPath);

        if (optionalDocument.isPresent()) {
            return optionalDocument.get().getBasePath() + "/" + optionalDocument.get().getDynamicPath();
        } else {
            throw new GeneralException("Document not found by given dynamic path:" + dynamicPath);
        }
    }

}
