package com.akinkemer.securechat.service;


import com.akinkemer.securechat.exception.*;
import com.akinkemer.securechat.model.dto.EnumDto;
import com.akinkemer.securechat.model.dto.UserDto;
import com.akinkemer.securechat.model.dto.request.*;
import com.akinkemer.securechat.model.dto.response.JwtResponse;
import com.akinkemer.securechat.model.dto.response.TokenRefreshResponse;
import com.akinkemer.securechat.model.entity.PasswordResetToken;
import com.akinkemer.securechat.model.entity.RefreshToken;
import com.akinkemer.securechat.model.entity.Role;
import com.akinkemer.securechat.model.entity.User;
import com.akinkemer.securechat.model.mapper.UserMapper;
import com.akinkemer.securechat.model.type.UserRole;
import com.akinkemer.securechat.repository.PasswordResetTokenRepository;
import com.akinkemer.securechat.repository.RoleRepository;
import com.akinkemer.securechat.repository.UserRepository;
import com.akinkemer.securechat.security.jwt.JwtUtils;
import com.akinkemer.securechat.security.services.RefreshTokenService;
import com.akinkemer.securechat.security.services.UserDetailsImpl;
import com.akinkemer.securechat.utilities.response.ErrorResponse;
import com.akinkemer.securechat.utilities.response.Response;
import com.akinkemer.securechat.utilities.response.SuccessResponse;
import com.akinkemer.securechat.utilities.util.RandomUtil;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
@Getter
@RequiredArgsConstructor
public class AuthService extends BaseService {

    private final AuthenticationManager authenticationManager;

    private final UserRepository userRepository;

    private final RoleRepository roleRepository;

    private final PasswordResetTokenRepository passwordResetTokenRepository;

    private final PasswordEncoder encoder;

    private final JwtUtils jwtUtils;

    private final RefreshTokenService refreshTokenService;

    private final MailService mailService;

    private final PasswordEncoder passwordEncoder;

    @Value("${app.passwordExpirationDay}")
    private int passwordExpirationDay;

    private boolean checkStringIsEmptyBlankOrNull(String string) {
        return string == null || string.isEmpty() || string.trim().isEmpty();
    }

    public ResponseEntity<?> authenticateUser(LoginRequest loginRequest) {

        String authUsername;

        if (!checkStringIsEmptyBlankOrNull(loginRequest.getUsername())) {
            authUsername = loginRequest.getUsername();
        } else {
            throw new IllegalArgumentException("Email dolu olmalıdır");
        }

        Authentication authentication;
        try {
            authentication = authenticationManager
                    .authenticate(new UsernamePasswordAuthenticationToken(authUsername, loginRequest.getPassword()));
        } catch (AuthenticationException authenticationEx) {
            log.error(authenticationEx.getMessage());
            throw new BadCredentialsException();
        }

        SecurityContextHolder.getContext().setAuthentication(authentication);

        UserDetailsImpl userDetails = (UserDetailsImpl) authentication.getPrincipal();

        User user = userRepository.findById(userDetails.getId())
                .orElseThrow(() -> new EntityNotFoundException(userDetails.getId().toString(), User.class));

        if (user.getStatus() != 1) {
            throw new BadCredentialsException();
        }

        if (user.getActive() != 1) {
            throw new UserNotActiveException();
        }

        String jwt = jwtUtils.generateJwtToken(userDetails);

        List<String> roles = userDetails
                .getAuthorities()
                .stream()
                .map(item -> item.getAuthority())
                .collect(Collectors.toList());

        RefreshToken refreshToken = refreshTokenService.createRefreshToken(userDetails.getId());

        Boolean isPasswordExpired = checkIsPasswordExpired(user);

        return ResponseEntity.ok(new JwtResponse(
                "Bearer " + jwt,
                refreshToken.getToken(),
                userDetails.getId(),
                userDetails.getUsername(),
                userDetails.getEmail(),
                roles, isPasswordExpired));
    }

    private Boolean checkIsPasswordExpired(User user) {
        if (user.getPasswordChangedLastAt() == null) {
            return true;
        }

        return user.getPasswordChangedLastAt()
                .plusDays(passwordExpirationDay)
                .isBefore(LocalDateTime.now());
    }


    public ResponseEntity<?> registerUser(SignupRequest signUpRequest) {
        if (userRepository.existsByEmail(signUpRequest.getEmail())) {
            throw new EmailAlreadyUsedException();
        }

        User user = new User();
        user.setName(signUpRequest.getName());
        user.setSurname(signUpRequest.getSurname());
        user.setEmail(signUpRequest.getEmail());
        user.setUsername(user.getEmail());
        user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));
        user.setPasswordChangedLastAt(LocalDateTime.now());


        Set<Role> roles = new HashSet<>();

        Role userRole = roleRepository.findByName(UserRole.USER)
                .orElseThrow(() -> new EntityNotFoundException(UserRole.USER.name(), Role.class));
        roles.add(userRole);

        user.setRoles(roles);
        userRepository.save(user);

        return ResponseEntity.ok("Kullanıcı başarıyla kaydedildi!");
    }

    public ResponseEntity<?> refreshtoken(TokenRefreshRequest request) {
        String requestRefreshToken = request.getRefreshToken();

        return refreshTokenService.findByToken(requestRefreshToken)
                .map(refreshTokenService::verifyExpiration)
                .map(RefreshToken::getUser)
                .map(user -> {
                    String token = jwtUtils.generateTokenFromUsername(user.getUsername());
                    return ResponseEntity.ok(new TokenRefreshResponse(token, requestRefreshToken));
                })
                .orElseThrow(() -> new TokenRefreshException(requestRefreshToken,
                        "Refresh token bulunamadı!"));
    }

    public ResponseEntity<?> logoutUser(LogOutRequest logOutRequest) {
        refreshTokenService.deleteByUserId(logOutRequest.getUserId());
        return ResponseEntity.ok("Log out successful!");
    }

    public ResponseEntity<?> getLoginUserDetail() {
        User user = getLoginUser();

        return ResponseEntity.ok(UserMapper.mapToUser(user, UserMapper
                .mapToList(userRepository.getChatUsers(user.getId()))));
    }

    public ResponseEntity<?> getUserList() {
        List<User> userList;
        userList = userRepository.getAll();

        return ResponseEntity.ok(UserMapper.mapToList(userList));
    }

    public ResponseEntity<?> updateUser(UpdateUserRequest updateUserRequest) {
        User user = userRepository.findById(updateUserRequest.getUserId())
                .orElseThrow(() -> new EntityNotFoundException(updateUserRequest.getUserId().toString(), User.class));

        if (!user.getEmail().equals(updateUserRequest.getEmail()) && userRepository.existsByEmail(updateUserRequest.getEmail())) {
            throw new EmailAlreadyUsedException();
        }

        user.setName(updateUserRequest.getName());
        user.setSurname(updateUserRequest.getSurname());
        user.setEmail(updateUserRequest.getEmail());
        user.setUsername(user.getEmail());

        Set<Role> roles = new HashSet<>();

        for (UserRole role : updateUserRequest.getRoles()) {
            Role userRole = roleRepository.findByName(role)
                    .orElseThrow(() -> new EntityNotFoundException(role.name(), Role.class));
            roles.add(userRole);
        }

        user.setRoles(roles);

        user = userRepository.save(user);

        return ResponseEntity.ok(UserMapper.mapTo(user));
    }

    public ResponseEntity<?> deleteUserById(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException(userId.toString(), User.class));

        user.setStatus(0);
        user = userRepository.save(user);
        return ResponseEntity.ok(UserMapper.mapTo(user));
    }

    @Transactional
    public Response forgetPassword(ForgetPasswordRequest request) {
        log.info("forgetPassword - request: " + request.toString());
        User user = null;
        if (!StringUtils.isEmpty(request.getEmail())) {
            user = userRepository.findByEmail(request.getEmail()).orElse(null);

        } else if (!StringUtils.isEmpty(request.getGsmNo())) {
            user = userRepository.findByGsmNo(request.getGsmNo()).orElse(null);
        }

        if (user != null) {
            User finalUser = user;
            PasswordResetToken passwordResetToken = passwordResetTokenRepository.getActiveByUserAndEndDateAfter(user, LocalDateTime.now()).orElseGet(() -> {
                PasswordResetToken _passwordResetToken = new PasswordResetToken();
                _passwordResetToken.setEndDate(LocalDateTime.now().plusMinutes(PasswordResetToken.EXPIRATION));
                _passwordResetToken.setUser(finalUser);
                String authCode;
                LocalDateTime now = LocalDateTime.now();
                do {
                    authCode = RandomUtil.randomNumString(4);
                } while (passwordResetTokenRepository.existsByPasswordResetAuthCodeAndStatusAndEndDateAfter(authCode, 1, now));
                _passwordResetToken.setPasswordResetAuthCode(authCode);
                _passwordResetToken = passwordResetTokenRepository.save(_passwordResetToken);
                return _passwordResetToken;
            });

            if (!StringUtils.isEmpty(request.getEmail())) {
                return mailService.sendCodeByMail(passwordResetToken, user);
            } else if (!StringUtils.isEmpty(request.getGsmNo())) {
                return mailService.sendCodeBySms(passwordResetToken, user);
            } else {
                return new ErrorResponse("Kullanıcı bilgileri eksik", HttpStatus.BAD_REQUEST);
            }
        } else {
            return new ErrorResponse("Kullanıcı bulunamadı", HttpStatus.BAD_REQUEST);
        }
    }

    @Transactional
    public Response resetPassword(ResetPasswordRequest request) {
        log.info("resetPassword - request: " + request.toString());
        Optional<PasswordResetToken> passwordResetTokenOptional =
                passwordResetTokenRepository.getActiveByTokenAndEndDateAfter(request.getPasswordResetAuthCode(), LocalDateTime.now());
        if (!passwordResetTokenOptional.isPresent()) {
            return new ErrorResponse("Doğrulama kodu geçersiz", HttpStatus.BAD_REQUEST);
        }
        PasswordResetToken passwordResetToken = passwordResetTokenOptional.get();
        User user = passwordResetToken.getUser();
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        passwordResetTokenRepository.updateStatusPassive(passwordResetToken.getId());
        return new SuccessResponse("Parola değiştirme işlemi başarılı", HttpStatus.OK);
    }


    public UserDto changeUserActivate(Long userId, Integer isActive) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException(userId.toString(), User.class));

        if (isActive != 0) {
            isActive = 1;
        }
        user.setActive(isActive);
        user = userRepository.save(user);
        return UserMapper.mapTo(user);
    }

    public ResponseEntity<?> changeUserPassword(Long userId, ChangeUserPasswordRequest request) {
        if (request.getCurrentPassword() == null) {
            throw new GeneralException("Eski parola kısmı boş olmamalıdır.");
        }

        if (request.getNewPassword() == null) {
            throw new GeneralException("Yeni parola kısmı boş olmamalıdır.");
        }

        if (request.getNewPassword().equals(request.getCurrentPassword())) {
            throw new GeneralException("Yeni parola eski parola ile aynı olmamalıdır.");
        }

        User user = getUserIfUserAndPasswordIsValid(userId, request.getCurrentPassword());
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        user.setPasswordChangedLastAt(LocalDateTime.now());
        userRepository.save(user);
        return ResponseEntity.ok().body("Şifre değiştirme işlemi başarılı");
    }

    private User getUserIfUserAndPasswordIsValid(Long userId, String password) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new EntityNotFoundException(userId.toString(), User.class));

        Authentication authentication;
        try {
            authentication = authenticationManager
                    .authenticate(new UsernamePasswordAuthenticationToken(user.getUsername(), password));
        } catch (AuthenticationException authenticationEx) {
            log.error(authenticationEx.getMessage());
            throw new GeneralException("Şifrenizi yanlış girdiniz");
        }
        return user;
    }

    public List<EnumDto> getUserRoles() {
        List<UserRole> userRoleList = new ArrayList<>();
        userRoleList.add(UserRole.USER);

        return userRoleList.stream()
                .map(role -> new EnumDto(role.name(), role.getScreenLabel()))
                .collect(Collectors.toList());
    }

    public boolean authenticateUserToken(AuthenticateUserRequest request) {
        String userName=jwtUtils.validateJwtTokenAndGetUserName(request.getToken());

        if(Objects.isNull(userName)){
            return Boolean.FALSE;
        }

       Optional<User> optionalUser= userRepository.findByUsername(userName);

        if(optionalUser.isPresent()){
            User user=optionalUser.get();
            if(user.getId().equals(request.getUserId())){
                return true;
            }
        }
        return false;
    }
}
