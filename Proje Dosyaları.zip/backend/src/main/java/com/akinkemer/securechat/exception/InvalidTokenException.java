package com.akinkemer.securechat.exception;

import com.akinkemer.securechat.utilities.exception.SecureChatException;

public class InvalidTokenException extends SecureChatException implements IErrorCode {

    public InvalidTokenException() {
        super(INVALID_TOKEN_EXCEPTION, null, null);
    }
}
