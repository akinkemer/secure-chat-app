package com.akinkemer.securechat.exception;

import com.akinkemer.securechat.utilities.exception.SecureChatException;
import org.springframework.http.HttpStatus;

public class UserNotActiveException extends SecureChatException implements IErrorCode {

    public UserNotActiveException() {
        super(USER_NOT_ACTIVE_EXCEPTION, null, null, null, null, HttpStatus.FORBIDDEN);
    }

}
