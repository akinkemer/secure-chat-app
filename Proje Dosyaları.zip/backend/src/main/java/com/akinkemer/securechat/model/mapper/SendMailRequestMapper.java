package com.akinkemer.securechat.model.mapper;


import com.akinkemer.securechat.model.dto.request.SendMailRequest;
import com.akinkemer.securechat.model.dto.request.SendMultiMailRequest;

public class SendMailRequestMapper {

    public static SendMailRequest mapTo(SendMultiMailRequest sendMultiMailRequest) {
        SendMailRequest sendMailRequest = new SendMailRequest();
        sendMailRequest.setSubjectPlaceHolders(sendMultiMailRequest.getSubjectPlaceHolders());
        sendMailRequest.setBodyPlaceHolders(sendMultiMailRequest.getBodyPlaceHolders());
        sendMailRequest.setImageDatum(sendMultiMailRequest.getImageDatum());
        sendMailRequest.setType(sendMultiMailRequest.getType());
        sendMailRequest.setBccAddress(sendMultiMailRequest.getBccAddress());
        sendMailRequest.setCcAddress(sendMultiMailRequest.getCcAddress());

        StringBuilder toAddressListBuilder = new StringBuilder();

        for (String address : sendMultiMailRequest.getToAddressList()) {
            toAddressListBuilder.append(address).append(";");
        }

        String toAddressList = toAddressListBuilder.toString();

        toAddressList = toAddressList.substring(0, toAddressList.length() - 1);

        sendMailRequest.setToAddress(toAddressList);

        return sendMailRequest;
    }

}
