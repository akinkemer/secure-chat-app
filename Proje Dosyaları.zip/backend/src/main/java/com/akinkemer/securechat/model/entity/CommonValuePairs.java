package com.akinkemer.securechat.model.entity;

import lombok.Data;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table
@Data
public class CommonValuePairs {

    private final static String SEQUENCE_NAME = "commonvalue_id";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_NAME + "_gen")
    @SequenceGenerator(name = SEQUENCE_NAME + "_gen", sequenceName = SEQUENCE_NAME, allocationSize = 1)
    private Long id;

    private Long user1;

    private Long user2;

    private Long p;

    private Long alfa;

    private LocalDateTime expiredAt;
}
