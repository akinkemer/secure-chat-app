package com.akinkemer.securechat.model.dto.request;

import lombok.Data;

import java.util.List;

@Data
public class SendGroupMessageRequest {
    List<Long> toBeSendUsers;
    Long fromUserId;
    String message;
}
