package com.akinkemer.securechat.model.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
public class UserDto {

    private Long id;

    private Integer status;

    private Integer active;

    private String name;

    private String surname;

    private String email;

    private List<EnumDto> roles = new ArrayList<>();

    private List<UserDto> users = new ArrayList<>();

}
