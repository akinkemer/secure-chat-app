package com.akinkemer.securechat.model.type;

public enum MailType {
    ACTIVATION,
    FORGOT_PASSWORD,
    OTP_CODE,
    TEST_TEXT,
    TEST_HTML
}
