package com.akinkemer.securechat.model.dto.request;

import lombok.Data;

@Data
public class AuthenticateUserRequest {
    Long userId;
    String token;
}
