package com.akinkemer.securechat.utilities.util;

import java.util.Random;

public class RandomUtil {
    private static final int LEFT_LIMIT = 48; // numeral '0'
    private static final int RIGHT_LIMIT = 122; // letter 'z'

    public static String randomAlpNumString(int size) {
        Random random = new Random();
        return random.ints(LEFT_LIMIT, RIGHT_LIMIT + 1)
                .filter(i -> (i <= 57 || i >= 65) && (i <= 90 || i >= 97))
                .limit(size)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString()
                .toUpperCase();

    }

    public static String randomNumString(int size) {
        Random random = new Random();
        return String.format("%0" + size + "d", random.nextInt(((int) Math.pow(10, size)) - 1));
    }
}
