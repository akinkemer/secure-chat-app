package com.akinkemer.securechat.service;

import com.akinkemer.securechat.exception.EntityNotFoundException;
import com.akinkemer.securechat.model.entity.User;
import com.akinkemer.securechat.repository.UserRepository;
import com.akinkemer.securechat.security.services.UserDetailsImpl;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public abstract class BaseService {

    protected final String SUCCESS_RESPONSE = "1";
    protected final String FAIL_RESPONSE = "0";

    @Value("${spring.application.name}")
    protected String applicationName;

    protected UserRepository getUserRepository() {
        throw new IllegalArgumentException("Please overwrite getMapUserRepository method!!! Cuz u used it!");
    }

    protected User getLoginUser() {
        return Optional.ofNullable((UserDetailsImpl) SecurityContextHolder.getContext().getAuthentication().getPrincipal())
                .map(user -> getUserRepository().findById(user.getId()).orElseThrow(() -> new EntityNotFoundException(user.getId().toString(), User.class)))
                .orElseThrow(() -> new IllegalArgumentException("Not Auth user"));
    }

}
