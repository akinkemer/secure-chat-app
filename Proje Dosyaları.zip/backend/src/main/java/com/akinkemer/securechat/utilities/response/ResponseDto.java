package com.akinkemer.securechat.utilities.response;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class ResponseDto {
    private boolean success;
    private LocalDateTime dateTime;
    private String message;

    public ResponseDto(boolean success,String message) {
        this.success = success;
        this.dateTime = LocalDateTime.now();
        this.message = message;
    }
}
