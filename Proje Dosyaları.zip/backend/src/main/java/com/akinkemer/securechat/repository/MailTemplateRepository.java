package com.akinkemer.securechat.repository;


import com.akinkemer.securechat.model.entity.mail.MailTemplate;
import com.akinkemer.securechat.model.type.MailType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MailTemplateRepository extends JpaRepository<MailTemplate, Long> {

    Optional<MailTemplate> findByType(MailType mailType);

}
