package com.akinkemer.securechat.model.entity;


import com.akinkemer.securechat.model.type.MessageType;
import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.time.LocalDateTime;

@Entity
@Table
@Data
public class Message {

    private final static String SEQUENCE_NAME = "message_id";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_NAME + "_gen")
    @SequenceGenerator(name = SEQUENCE_NAME + "_gen", sequenceName = SEQUENCE_NAME, allocationSize = 1)
    private Long id;

    @Column(nullable = false)
    private int status = 1;

    String message;

    LocalDateTime sendAt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "from_user_id")
    User from;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "to_user_id")
    User to;

    @NotNull
    @Column(columnDefinition = "boolean default false")
    Boolean isPublic;

    @NotNull
    @Column(columnDefinition = "boolean default false")
    Boolean isCertificate;

    @NotNull
    @Column(columnDefinition = "boolean default false")
    Boolean isConnected;

}
