package com.akinkemer.securechat.controller;


import com.akinkemer.securechat.model.dto.MessageDto;
import com.akinkemer.securechat.model.dto.request.GetPAndAlfaRequest;
import com.akinkemer.securechat.model.dto.request.SendGroupMessageRequest;
import com.akinkemer.securechat.model.dto.request.SendMessageRequest;
import com.akinkemer.securechat.service.MessageService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.DestinationVariable;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.annotation.SubscribeMapping;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
public class MessageController extends BaseController {

    private final MessageService messageService;

    @MessageMapping("/private-message")
    public void receiveMessage(@Payload SendMessageRequest request) {
        messageService.receiveMessage(request.getToUserId(), request);

    }

    @MessageMapping("/message")
    @SendTo("/chatroom/public")
    public MessageDto receivePublicMessage(@Payload SendMessageRequest request) {
        return messageService.receivePublicMessage(request);
    }

    @GetMapping(API_MESSAGES)
    public List<MessageDto> getPublicMessages() {
        return messageService.getPublicMessages();
    }

    @GetMapping(API_PRIVATE_MESSAGES)
    public List<MessageDto> getPrivateMessages(@PathVariable Long senderId,
                                               @PathVariable Long receiverId) {
        return messageService.getPrivateMessages(senderId,receiverId);
    }

    @PostMapping(API_GROUP_MESSAGE)
    public ResponseEntity<String> sendGroupMessage(@RequestBody SendGroupMessageRequest request) {
        return messageService.sendGroupMessage(request);
    }

    @PostMapping(API_P_AND_ALFA)
    public ResponseEntity<?> getPAndAlfa(@RequestBody GetPAndAlfaRequest request) {
        return messageService.getPAndAlfa(request);
    }


}
