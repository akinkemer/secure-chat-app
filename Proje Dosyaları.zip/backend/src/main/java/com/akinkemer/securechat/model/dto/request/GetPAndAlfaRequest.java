package com.akinkemer.securechat.model.dto.request;

import lombok.Data;

@Data
public class GetPAndAlfaRequest {
    Long senderId;
    Long receiverId;
}
