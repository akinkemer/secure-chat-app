package com.akinkemer.securechat.repository;


import com.akinkemer.securechat.model.entity.mail.MailSendingLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MailSendingLogRepository extends JpaRepository<MailSendingLog, Long> {

}
