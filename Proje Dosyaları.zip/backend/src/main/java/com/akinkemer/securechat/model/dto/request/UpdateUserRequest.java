package com.akinkemer.securechat.model.dto.request;

import com.akinkemer.securechat.model.type.UserRole;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class UpdateUserRequest {

    private Long userId;

    private String name;

    private String surname;

    private String email;

    private List<UserRole> roles = new ArrayList<>();

}
