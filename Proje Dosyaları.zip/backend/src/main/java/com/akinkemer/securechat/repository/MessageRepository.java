package com.akinkemer.securechat.repository;

import com.akinkemer.securechat.model.entity.Message;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MessageRepository extends JpaRepository<Message, Long> {

    @Query("SELECT DISTINCT m FROM Message m " +
            "LEFT JOIN FETCH m.to toUser " +
            "LEFT JOIN FETCH m.from fromUser " +
            "WHERE m.isPublic is true order by m.sendAt")
    List<Message> getPublicMessages();

    @Query("SELECT DISTINCT m FROM Message m " +
            "LEFT JOIN FETCH m.to toUser " +
            "LEFT JOIN FETCH m.from fromUser " +
            "WHERE (m.isPublic IS NULL OR m.isPublic IS FALSE)  " +
            "AND (m.isCertificate IS NULL OR m.isCertificate IS FALSE) " +
            "AND ((toUser.id = :receiverId AND fromUser.id =:senderId) OR (toUser.id = :senderId AND fromUser.id =:receiverId) )" +
            "order by m.sendAt")
    List<Message> getPrivateMessages(Long senderId, Long receiverId);
}
