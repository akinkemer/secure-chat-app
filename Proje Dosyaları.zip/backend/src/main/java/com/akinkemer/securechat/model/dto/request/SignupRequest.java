package com.akinkemer.securechat.model.dto.request;

import com.akinkemer.securechat.model.type.UserRole;
import lombok.Getter;

import java.util.ArrayList;
import java.util.List;

@Getter
public class SignupRequest {

    private String name;

    private String surname;

    private String email;

    private String password;

}
