package com.akinkemer.securechat.model.type;

public enum MessageType {
    HELLO, P_ALFA, CERTIFICATE;
}
