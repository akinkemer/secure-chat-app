package com.akinkemer.securechat.model.type;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public enum UserRole implements HasScreenLabel {

    USER("Kullanıcı", false),
    ADMIN("Admin", false);


    public final String screenLabel;
    private final boolean webService;

}
