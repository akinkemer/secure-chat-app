package com.akinkemer.securechat.service;

import com.akinkemer.securechat.exception.EntityNotFoundException;
import com.akinkemer.securechat.model.dto.MessageDto;
import com.akinkemer.securechat.model.dto.request.GetPAndAlfaRequest;
import com.akinkemer.securechat.model.dto.request.SendGroupMessageRequest;
import com.akinkemer.securechat.model.dto.request.SendMessageRequest;
import com.akinkemer.securechat.model.entity.CommonValuePairs;
import com.akinkemer.securechat.model.entity.Message;
import com.akinkemer.securechat.model.entity.User;
import com.akinkemer.securechat.repository.CommonValuePairsRepository;
import com.akinkemer.securechat.repository.MessageRepository;
import com.akinkemer.securechat.repository.UserRepository;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

@Slf4j
@Service
@Getter
@RequiredArgsConstructor
public class MessageService extends BaseService {

    private final MessageRepository messageRepository;

    private final UserRepository userRepository;

    private final CommonValuePairsRepository commonValuePairsRepository;

    private final SimpMessagingTemplate simpMessagingTemplate;

    public void receiveMessage(Long toUserId, SendMessageRequest request) {
        User to = userRepository.findById(toUserId)
                .orElseThrow(() -> new EntityNotFoundException(toUserId.toString(), User.class));

        User from = userRepository.findById(request.getFromUserId())
                .orElseThrow(() -> new EntityNotFoundException(request.getFromUserId().toString(), User.class));

        Message message = new Message();
        message.setTo(to);
        message.setFrom(from);
        message.setIsPublic(false);
        message.setMessage(request.getMessage());
        message.setSendAt(LocalDateTime.now());
        message.setIsCertificate(request.getIsCertificate());
        message.setIsConnected(request.getIsConnected());
        if (request.getIsCertificate() == null || !request.getIsCertificate()) {
            messageRepository.save(message);
        }
        simpMessagingTemplate.convertAndSendToUser(toUserId.toString(), "/private", new MessageDto(message));
    }

    public MessageDto receivePublicMessage(SendMessageRequest request) {
        User user = userRepository.findById(request.getFromUserId())
                .orElseThrow(() -> new EntityNotFoundException(request.getFromUserId().toString(), User.class));

        Message message = new Message();
        message.setIsPublic(true);
        message.setMessage(request.getMessage());
        message.setSendAt(LocalDateTime.now());
        message.setFrom(user);
        message = messageRepository.save(message);
        return new MessageDto(message);
    }

    public List<MessageDto> getPublicMessages() {
        return messageRepository.getPublicMessages().stream()
                .map(MessageDto::new)
                .collect(Collectors.toList());
    }

    public List<MessageDto> getPrivateMessages(Long senderId, Long receiverId) {
        User senderUser = userRepository.findById(senderId)
                .orElseThrow(() -> new EntityNotFoundException(senderId.toString(), User.class));

        User receiverUser = userRepository.findById(receiverId)
                .orElseThrow(() -> new EntityNotFoundException(receiverId.toString(), User.class));

        return messageRepository.getPrivateMessages(senderId, receiverId).stream()
                .map(MessageDto::new)
                .collect(Collectors.toList());
    }

    public ResponseEntity<String> sendGroupMessage(SendGroupMessageRequest request) {
        User senderUser = userRepository.findById(request.getFromUserId())
                .orElseThrow(() -> new EntityNotFoundException(request.getFromUserId().toString(), User.class));

        if (request.getToBeSendUsers() == null) {
            return ResponseEntity.ok().body(SUCCESS_RESPONSE);
        }

        request.getToBeSendUsers().forEach(userId -> {
            User toUser = userRepository.findById(userId)
                    .orElseThrow(() -> new EntityNotFoundException(userId.toString(), User.class));

            Message message = new Message();
            message.setMessage(request.getMessage());
            message.setSendAt(LocalDateTime.now());
            message.setIsPublic(false);
            message.setTo(toUser);
            message.setFrom(senderUser);
            messageRepository.save(message);

            simpMessagingTemplate.convertAndSendToUser(userId.toString(), "/private", new MessageDto(message));
        });

        return ResponseEntity.ok().body(SUCCESS_RESPONSE);
    }

    public ResponseEntity<?> getPAndAlfa(GetPAndAlfaRequest request) {

        List<CommonValuePairs> optionalPairs = commonValuePairsRepository.findPairs(request.getReceiverId(), request.getSenderId());

        if (optionalPairs.size() > 0) {
            return ResponseEntity.ok(optionalPairs.get(0));
        }

        CommonValuePairs commonValuePairs = new CommonValuePairs();

        Random random = new Random();
        BigInteger pBigInteger = BigInteger.probablePrime(32, random);
        System.out.println("BigInteger:" + pBigInteger);
        Long p = Math.abs(pBigInteger.longValue());
        System.out.println("p:" + p);
        Long alfa = 1 + random.nextLong() % (p - 1);
        System.out.println("alfa:" + alfa);

        commonValuePairs.setAlfa(alfa);
        commonValuePairs.setP(p);
        commonValuePairs.setExpiredAt(LocalDateTime.now().plusMinutes(10));
        commonValuePairs.setUser1(request.getReceiverId());
        commonValuePairs.setUser2(request.getSenderId());
        commonValuePairsRepository.save(commonValuePairs);

        return ResponseEntity.ok(commonValuePairs);
    }
}
