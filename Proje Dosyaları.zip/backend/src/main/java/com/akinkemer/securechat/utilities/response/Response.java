package com.akinkemer.securechat.utilities.response;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;


public abstract class Response extends ResponseEntity {

    public Response(Object body, HttpStatus status) {
        super(body, status);
    }
}
