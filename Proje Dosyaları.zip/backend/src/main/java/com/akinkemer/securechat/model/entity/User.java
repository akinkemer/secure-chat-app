package com.akinkemer.securechat.model.entity;

import com.akinkemer.securechat.config.AttributeEncryptor;
import com.akinkemer.securechat.model.base.ExtendedModel;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "users")
public class User extends ExtendedModel {

    @JsonIgnore
    @Column(name = "username", unique = true)
    @Convert(converter = AttributeEncryptor.class)
    private String username;

    @JsonIgnore
    private String password;

    @JsonIgnore
    private LocalDateTime passwordChangedLastAt;

    @Column(name = "name")
    private String name;

    @Column(name = "surname")
    private String surname;

    @Column(name = "email")
    @Convert(converter = AttributeEncryptor.class)
    private String email;

    @Column(name = "gsmNo")
    @Convert(converter = AttributeEncryptor.class)
    private String gsmNo;

    @JsonIgnore
    @OneToMany(mappedBy = "user", fetch = FetchType.LAZY)
    private List<PasswordResetToken> passwordResetTokens = new ArrayList<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "to")
    List<Message> receivedMessages;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "from")
    List<Message> sentMessages;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(name = "user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<Role> roles = new HashSet<>();

    public User(String username, String password, String email) {
        this.username = username;
        this.password = password;
        this.email = email;
    }
}
