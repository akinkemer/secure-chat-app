package com.akinkemer.securechat.utilities.response;

import org.springframework.http.HttpStatus;

public class SuccessResponse extends Response {

    public SuccessResponse(String message, HttpStatus status) {
        super(new ResponseDto(true, message), status);
    }
}
