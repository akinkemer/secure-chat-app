package com.akinkemer.securechat.service;


import com.akinkemer.securechat.exception.EntityNotFoundException;
import com.akinkemer.securechat.model.dto.request.SendMailRequest;
import com.akinkemer.securechat.model.entity.PasswordResetToken;
import com.akinkemer.securechat.model.entity.User;
import com.akinkemer.securechat.model.entity.mail.Mail;
import com.akinkemer.securechat.model.entity.mail.MailImage;
import com.akinkemer.securechat.model.entity.mail.MailTemplate;
import com.akinkemer.securechat.model.type.MailType;
import com.akinkemer.securechat.repository.MailImageRepository;
import com.akinkemer.securechat.repository.MailRepository;
import com.akinkemer.securechat.repository.MailTemplateRepository;
import com.akinkemer.securechat.utilities.response.Response;
import com.akinkemer.securechat.utilities.response.SuccessResponse;
import lombok.RequiredArgsConstructor;
import net.logstash.logback.encoder.org.apache.commons.lang.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

@Service
@RequiredArgsConstructor
public class MailService extends BaseService {

    private final MailRepository mailRepository;
    private final MailImageRepository mailImageRepository;
    private final MailTemplateRepository mailTemplateRepository;
    private final MailSender mailSender;

    private Mail createMail(SendMailRequest request, String applicationName) {
        MailTemplate mailTemplate = mailTemplateRepository.findByType(request.getType())
                .orElseThrow(() -> new EntityNotFoundException(null, MailTemplate.class));

        Mail mail = new Mail();
        mail.setMailTemplate(mailTemplate);
        mail.setBccAddress(request.getBccAddress());
        mail.setCcAddress(request.getCcAddress());
        mail.setType(request.getType());
        mail.setHtml(mailTemplate.isHtml());
        String mailSubject = mailTemplate.getSubject();
        if (!StringUtils.isBlank(mailTemplate.getSubjectPlaceHolders())) {
            for (String placeHolder : mailTemplate.getSubjectPlaceHolders().split(MailTemplate.SPLITTER)) {
                mailSubject = mailSubject.replace("$$" + placeHolder + "$$", request.getSubjectPlaceHolders().get(placeHolder));
            }
        }
        mail.setSubject(mailSubject);

        String mailBody = mailTemplate.getBody();
        if (!StringUtils.isBlank(mailTemplate.getBodyPlaceHolders())) {
            for (String placeHolder : mailTemplate.getBodyPlaceHolders().split(MailTemplate.SPLITTER)) {
                mailBody = mailBody.replace("$$" + placeHolder + "$$", request.getBodyPlaceHolders().get(placeHolder));
            }
        }

        mail.setBody(mailBody);

        mail.setToAddress(request.getToAddress());
        mail = mailRepository.save(mail);

        if (!CollectionUtils.isEmpty(request.getImageDatum())) {

            Mail finalMail = mail;
            request.getImageDatum().forEach((key, value) -> {
                MailImage mailImage = new MailImage();
                mailImage.setMail(finalMail);

                mailImage.setName(key);
                mailImage.setDatum(value);
                mailImageRepository.save(mailImage);
            });
        }

        return mail;
    }

    public Mail createMailAndSend(SendMailRequest request) {
        Mail mail = createMail(request, applicationName);
        return mailSender.sendMail(mail.getId());
    }


    public Response sendCodeByMail(PasswordResetToken passwordResetToken, User user) {
        SendMailRequest request = new SendMailRequest();
        request.setType(MailType.FORGOT_PASSWORD);
        request.setToAddress(user.getEmail());
        request.getBodyPlaceHolders().put("name", user.getName() + " " + user.getSurname());
        request.getBodyPlaceHolders().put("authCode", passwordResetToken.getPasswordResetAuthCode());
        request.getSubjectPlaceHolders().put("appName", applicationName);
        createMailAndSend(request);
        return new SuccessResponse("Mail gönderme işlemi başarılı", HttpStatus.OK);
    }

    public Response sendCodeBySms(PasswordResetToken passwordResetToken, User user) {
        return new SuccessResponse("SMS gönderme işlemi başarılı", HttpStatus.OK);
    }

}
