package com.akinkemer.securechat.repository;


import com.akinkemer.securechat.model.entity.mail.Mail;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MailRepository extends JpaRepository<Mail, Long> {

}
