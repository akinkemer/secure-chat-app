package com.akinkemer.securechat.config.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "spring.mail.sender")
public class CustomMailProperties extends MailProperties {

}
