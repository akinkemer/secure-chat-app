package com.akinkemer.securechat.repository;


import com.akinkemer.securechat.model.entity.mail.MailImage;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MailImageRepository extends JpaRepository<MailImage, Long> {

}
