package com.akinkemer.securechat.controller;


import com.akinkemer.securechat.model.dto.EnumDto;
import com.akinkemer.securechat.model.dto.UserDto;
import com.akinkemer.securechat.model.dto.request.*;
import com.akinkemer.securechat.model.type.UserRole;
import com.akinkemer.securechat.service.AuthService;
import com.akinkemer.securechat.utilities.response.Response;
import io.swagger.annotations.ApiOperation;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


@RestController
@RequiredArgsConstructor
public class AuthController extends BaseController {
    private final AuthService authService;

    @PostMapping(AUTH_LOGIN)
    @ApiOperation("Gönderilen kullanici adi ile sifre kontrolu gerceklestirir")
    public ResponseEntity<?> authenticateUser(@RequestBody LoginRequest loginRequest) {
        return authService.authenticateUser(loginRequest);
    }

    @PostMapping(AUTH_AUTHENTICATE)
    @ApiOperation("Gönderilen kullanici id'si ve token eşleşiyormu kontrol eder")
    public Boolean authenticateUserToken(@RequestBody AuthenticateUserRequest request) {
        return authService.authenticateUserToken(request);
    }

    @PostMapping(AUTH_REFRESH_TOKEN)
    @ApiOperation("Gonderilen tokeni guncel token ile degistirir.")
    public ResponseEntity<?> refreshtoken(@RequestBody TokenRefreshRequest tokenRefreshRequest) {
        return authService.refreshtoken(tokenRefreshRequest);
    }

    @PostMapping(AUTH_LOGOUT)
    @ApiOperation("Gonderilen tokeni siler")
    public ResponseEntity<?> logoutUser(@RequestBody LogOutRequest logOutRequest) {
        return authService.logoutUser(logOutRequest);
    }

    @PostMapping(API_REGISTER)
    @ApiOperation("Kullanici kayit servisi")
    public ResponseEntity<?> registerUser(@RequestBody SignupRequest signUpRequest) {
        return authService.registerUser(signUpRequest);
    }

    @PostMapping(PUBLIC_FORGOT_PASSWORD)
    @ApiOperation("Email ya da Gsm No ile şifre resetleme tokenı uretip, sms ya da maille gönderir")
    public Response forgetPassword(@RequestBody ForgetPasswordRequest request) {
        return authService.forgetPassword(request);
    }

    @PostMapping(PUBLIC_RESET_PASSWORD)
    @ApiOperation("Token ile sifre günceller")
    public Response resetPassword(@RequestBody ResetPasswordRequest request) {
        return authService.resetPassword(request);
    }

    @PostMapping(API_USER_CHANGE_PASSWORD)
    @ApiOperation("Kullanici şifre güncelleme servisi")
    public ResponseEntity<?> changeUserPassword(@PathVariable Long userId,
                                                @RequestBody ChangeUserPasswordRequest request) {
        return authService.changeUserPassword(userId, request);
    }

    @GetMapping(API_OWN)
    @ApiOperation("Gönderilen tokenin user bilgilerini doner.")
    public ResponseEntity<?> getLoginUserDetail() {
        return authService.getLoginUserDetail();
    }

    @GetMapping(API_USER_LIST)
    @ApiOperation("User listesi döner.")
    public ResponseEntity<?> getUserList() {
        return authService.getUserList();
    }

    @PostMapping(API_USER_UPDATE)
    @ApiOperation("Kullanici guncelleme servisi")
    public ResponseEntity<?> updateUser(@RequestBody UpdateUserRequest updateUserRequest) {
        return authService.updateUser(updateUserRequest);
    }

    @DeleteMapping(API_USER_DELETE)
    @ApiOperation("user silme servisi, durumu 0'a çeker")
    public ResponseEntity<?> deleteUserById(@PathVariable Long userId) {
        return authService.deleteUserById(userId);
    }

    @PostMapping(API_USER_CHANGE_ACTIVATE)
    @ApiOperation("Kullanıcı aktifliğini günceller")
    public UserDto changeUserActivate(@PathVariable("id") Long userId,
                                      @PathVariable("isActive") Integer isActive) {
        return authService.changeUserActivate(userId, isActive);
    }

    @GetMapping(API_USER_ROLES)
    @ApiOperation("rolleri donen servis")
    public List<EnumDto> getUserRoles() {
        return authService.getUserRoles();
    }

    @GetMapping(PUBLIC_USER_ROLES)
    @ApiOperation("bütün rolleri donen servis")
    public List<EnumDto> getRoles() {
        return Arrays.stream(UserRole.values())
                .map(role -> new EnumDto(role.name(), role.getScreenLabel()))
                .collect(Collectors.toList());
    }


}
