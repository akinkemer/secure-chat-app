package com.akinkemer.securechat.model.dto;

import com.akinkemer.securechat.model.entity.Message;
import lombok.Data;


import java.time.LocalDateTime;

@Data
public class MessageDto {
    Long id;
    String message;
    String fromName;
    LocalDateTime sendAt;
    Long fromId;
    Long toId;
    Boolean isReceived;
    Boolean isPublic;
    Boolean isCertificate;
    Boolean isConnected;

    public MessageDto(Message message) {
        this.setId(message.getId());
        this.setMessage(message.getMessage());
        this.setSendAt(message.getSendAt());
        this.setIsPublic(message.getIsPublic());
        this.setIsCertificate(message.getIsCertificate());
        this.setIsConnected(message.getIsConnected());

        if (message.getFrom() != null) {
            this.setFromId(message.getFrom().getId());
            this.setFromName(message.getFrom().getName() + " " + message.getFrom().getSurname());
        }

        if (message.getTo() != null) {
            this.setToId(message.getTo().getId());
        }

    }

    public MessageDto() {
    }
}
