package com.akinkemer.securechat.model.entity;

import com.akinkemer.securechat.model.base.ExtendedModel;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDateTime;

@Getter
@Setter
@Entity
public class PasswordResetToken extends ExtendedModel {

    public static final int EXPIRATION = 60 * 24;

    public static final String ID_GENERATOR = "password_id";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = ID_GENERATOR)
    @SequenceGenerator(name = ID_GENERATOR, sequenceName = ID_GENERATOR + "_seq", allocationSize = 1)
    private Long id;

    private String passwordResetAuthCode;

    @ManyToOne(fetch = FetchType.LAZY)
    private User user;

    private LocalDateTime endDate;
}
