package com.akinkemer.securechat.model.entity.mail;

import com.akinkemer.securechat.model.base.ExtendedModel;
import com.akinkemer.securechat.model.type.MailType;
import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Entity
public class Mail extends ExtendedModel {

    private final static String SEQUENCE_NAME = "mail_id";
    public final static String SPLITTER = ";";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_NAME + "_gen")
    @SequenceGenerator(name = SEQUENCE_NAME + "_gen", sequenceName = SEQUENCE_NAME, allocationSize = 1)
    private Long id;

    @Column(columnDefinition = "TEXT")
    private String toAddress;

    private String bccAddress;

    private String ccAddress;

    private String subject;

    @Enumerated(EnumType.STRING)
    private MailType type;

    @Column(columnDefinition = "TEXT")
    private String body;

    private boolean isHtml;

    private Boolean send;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "mail")
    private List<MailImage> mailImages = new ArrayList<>();

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    private MailTemplate mailTemplate;

    @JsonIgnore
    @OneToOne(fetch = FetchType.LAZY)
    private MailSendingLog lastMailSendingLog;

    @JsonIgnore
    @OneToMany(fetch = FetchType.LAZY, mappedBy = "mail")
    private List<MailSendingLog> mailSendingLogs = new ArrayList<>();
}
