package com.akinkemer.securechat.service;

import com.akinkemer.securechat.model.entity.mail.Mail;
import com.akinkemer.securechat.model.entity.mail.MailImage;
import com.akinkemer.securechat.model.entity.mail.MailSendingLog;
import com.akinkemer.securechat.repository.MailRepository;
import com.akinkemer.securechat.repository.MailSendingLogRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import net.logstash.logback.encoder.org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.commons.lang3.CharEncoding;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.activation.DataHandler;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class MailSender {

    @Qualifier("isgSender")
    private final JavaMailSender isgSender;

    private final MailRepository mailRepository;

    private final MailSendingLogRepository mailSendingLogRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();


    private JavaMailSenderImpl getJavaMailSender() {
        return (JavaMailSenderImpl) isgSender;
    }

    public MimeMessage prepareMail(Mail mail) throws MessagingException {
        JavaMailSenderImpl mailSender = getJavaMailSender();
        MimeMessage mimeMessage = mailSender.createMimeMessage();

        MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, CharEncoding.UTF_8);
        if (!CollectionUtils.isEmpty(mail.getMailImages())) {
            helper = new MimeMessageHelper(mimeMessage, true, CharEncoding.UTF_8);
        }
        helper.setText(mail.getBody(), mail.isHtml());
        helper.setTo(mail.getToAddress().split(Mail.SPLITTER));
        if (!Objects.isNull(mail.getBccAddress())) {
            helper.setBcc(mail.getBccAddress().split(Mail.SPLITTER));
        }
        if (!Objects.isNull(mail.getCcAddress())) {
            helper.setCc(mail.getCcAddress().split(Mail.SPLITTER));
        }
        String from = "SECURE CHAT APP";
        helper.setFrom(from + "<" + mailSender.getUsername() + ">");
        helper.setSubject(mail.getSubject());

        for (MailImage mailImage : mail.getMailImages()) {

            // create a new imagePart and add it to multipart so that the image is inline attached in the email
            byte[] rawImage = Base64.getDecoder().decode(mailImage.getDatum());
            BodyPart imagePart = new MimeBodyPart();
            ByteArrayDataSource imageDataSource = new ByteArrayDataSource(rawImage, "image/png");

            imagePart.setDataHandler(new DataHandler(imageDataSource));
            imagePart.setHeader("Content-ID", "<" + mailImage.getName() + ">");
            imagePart.setFileName(mailImage.getName() + ".png");

            helper.getRootMimeMultipart().addBodyPart(imagePart);
        }
        return mimeMessage;
    }


    public Mail sendMail(Long mailId) {
        Mail mail = mailRepository.findById(mailId).get();
        MailSendingLog mailSendingLog = new MailSendingLog();
        mailSendingLog.setMail(mail);
        mailSendingLog.setTime(LocalDateTime.now());
        try {
            mailSendingLog.setRequest(objectMapper.writeValueAsString(mail));
            getJavaMailSender().send(prepareMail(mail));
            mail.setSend(Boolean.TRUE);
        } catch (Exception e) {
            e.printStackTrace();
            mail.setSend(Boolean.FALSE);
            mailSendingLog.setErrorMessage(ExceptionUtils.getStackTrace(e));
        } finally {
            mailSendingLog.setMail(mail);
            mailSendingLog = mailSendingLogRepository.save(mailSendingLog);

            mail.setLastMailSendingLog(mailSendingLog);
            return mailRepository.save(mail);
        }
    }
}
