package com.akinkemer.securechat.model.dto.request;

import com.akinkemer.securechat.model.type.MailType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Getter
@Setter
@ToString
public class SendMultiMailRequest {

    private Map<String, String> subjectPlaceHolders = new HashMap<>();

    private Map<String, String> bodyPlaceHolders = new HashMap<>();

    private Map<String, String> imageDatum = new HashMap<>();

    private MailType type;

    private List<String> toAddressList = new ArrayList<>();

    private String bccAddress;

    private String ccAddress;

}
