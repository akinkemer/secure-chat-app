package com.akinkemer.securechat.repository;

import com.akinkemer.securechat.model.entity.CommonValuePairs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface CommonValuePairsRepository extends JpaRepository<CommonValuePairs, Long> {

    @Query("SELECT p FROM CommonValuePairs  p " +
            "WHERE ((p.user1=:user1 and p.user2=:user2) or (p.user1=:user2 and p.user2=:user1)) " +
            "AND p.expiredAt > current_timestamp ")
    List<CommonValuePairs> findPairs(Long user1, Long user2);
}
