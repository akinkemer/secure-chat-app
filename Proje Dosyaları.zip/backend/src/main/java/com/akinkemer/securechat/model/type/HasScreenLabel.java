package com.akinkemer.securechat.model.type;

public interface HasScreenLabel {

    String getScreenLabel();

    String name();
}
