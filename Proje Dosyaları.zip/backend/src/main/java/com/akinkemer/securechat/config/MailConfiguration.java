package com.akinkemer.securechat.config;

import com.akinkemer.securechat.config.properties.CustomMailProperties;
import com.akinkemer.securechat.config.properties.MailProperties;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Map;
import java.util.Properties;

@Configuration
@RequiredArgsConstructor
public class MailConfiguration {

    private final CustomMailProperties customMailProperties;

    @Bean
    public JavaMailSender isgSender() {
        JavaMailSenderImpl sender = new JavaMailSenderImpl();
        applyProperties(sender, customMailProperties);
        return sender;
    }

    private void applyProperties(JavaMailSenderImpl sender, MailProperties mailProperties) {
        sender.setHost(mailProperties.getHost());
        if (mailProperties.getPort() != null) {
            sender.setPort(mailProperties.getPort());
        }
        sender.setUsername(mailProperties.getUsername());
        sender.setPassword(mailProperties.getPassword());
        sender.setProtocol(mailProperties.getProtocol());
        if (mailProperties.getDefaultEncoding() != null) {
            sender.setDefaultEncoding(mailProperties.getDefaultEncoding().name());
        }
        if (!mailProperties.getProperties().isEmpty()) {
            sender.setJavaMailProperties(asProperties(mailProperties.getProperties()));
        }
    }

    private Properties asProperties(Map<String, String> source) {
        Properties properties = new Properties();
        properties.putAll(source);
        return properties;
    }
}