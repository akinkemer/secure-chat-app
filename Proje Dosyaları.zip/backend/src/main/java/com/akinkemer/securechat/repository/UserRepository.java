package com.akinkemer.securechat.repository;

import com.akinkemer.securechat.model.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByUsername(String username);

    Optional<User> findByEmail(String email);

    Optional<User> findByGsmNo(String gsmNo);

    Boolean existsByEmail(String email);

    @Query("select distinct u from User u where u.status=1 ")
    List<User> getAll();

    @Query("select distinct u from User u " +
            "where u.status=1 and u.id<>:userId  ")
    List<User> getChatUsers(Long userId);


}
