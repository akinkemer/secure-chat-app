package com.akinkemer.securechat.controller;

import com.akinkemer.securechat.service.FileService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class FileController extends BaseController {

    private final FileService fileService;

    @GetMapping(API_DOWNLOAD_FILE)
    public ResponseEntity downloadFile(@RequestParam(name = "path") String path) {
        return fileService.downloadFile(path);
    }
}
