package com.akinkemer.securechat.model.mapper;

import com.akinkemer.securechat.model.dto.UserDto;
import com.akinkemer.securechat.model.entity.User;


import java.util.ArrayList;
import java.util.List;

public class UserMapper {

    public static UserDto mapTo(User entity) {
        UserDto dto = new UserDto();
        dto.setStatus(entity.getStatus());
        dto.setActive(entity.getActive());
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setSurname(entity.getSurname());
        dto.setEmail(entity.getEmail());
        dto.setRoles(RoleMapper.mapToList(entity.getRoles()));

        return dto;
    }

    public static UserDto mapToUser(User entity, List<UserDto> users) {
        UserDto dto = new UserDto();
        dto.setStatus(entity.getStatus());
        dto.setActive(entity.getActive());
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setSurname(entity.getSurname());
        dto.setEmail(entity.getEmail());
        dto.setRoles(RoleMapper.mapToList(entity.getRoles()));
        dto.setUsers(users);

        return dto;
    }


    public static List<UserDto> mapToList(List<User> userList) {
        List<UserDto> dtoList = new ArrayList<>();
        for (User user : userList) {
            dtoList.add(mapTo(user));
        }
        return dtoList;
    }
}
