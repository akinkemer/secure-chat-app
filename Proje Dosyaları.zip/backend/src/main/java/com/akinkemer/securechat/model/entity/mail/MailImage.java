package com.akinkemer.securechat.model.entity.mail;

import com.akinkemer.securechat.model.base.ExtendedModel;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
public class MailImage extends ExtendedModel {

    private final static String SEQUENCE_NAME = "mail_image_id";
    public final static String SPLITTER = ";";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_NAME + "_gen")
    @SequenceGenerator(name = SEQUENCE_NAME + "_gen", sequenceName = SEQUENCE_NAME, allocationSize = 1)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    private Mail mail;

    private String name;

    private String datum;
}
