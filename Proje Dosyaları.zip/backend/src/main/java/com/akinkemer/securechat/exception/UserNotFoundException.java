package com.akinkemer.securechat.exception;

import com.akinkemer.securechat.utilities.exception.SecureChatException;
import org.springframework.http.HttpStatus;

public class UserNotFoundException extends SecureChatException implements IErrorCode {

    private static final long serialVersionUID = 1L;

    public UserNotFoundException(String field) {
        super(USER_NOT_FOUND_EXCEPTION, null, null, new String[]{"field"}, new String[]{field}, HttpStatus.BAD_REQUEST);
    }

}