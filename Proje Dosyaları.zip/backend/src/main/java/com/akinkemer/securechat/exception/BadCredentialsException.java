package com.akinkemer.securechat.exception;

import com.akinkemer.securechat.utilities.exception.SecureChatException;
import org.springframework.http.HttpStatus;

public class BadCredentialsException extends SecureChatException implements IErrorCode {

    public BadCredentialsException() {
        super(BAD_CREDENTIALS_EXCEPTION, null, null, null, null, HttpStatus.BAD_REQUEST);
    }

}