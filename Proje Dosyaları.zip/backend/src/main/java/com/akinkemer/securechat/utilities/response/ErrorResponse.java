package com.akinkemer.securechat.utilities.response;

import org.springframework.http.HttpStatus;

public class ErrorResponse extends Response{
    public ErrorResponse(String message, HttpStatus status) {
        super(new ResponseDto(false, message), status);
    }
}
