package com.akinkemer.securechat.model.dto.request;

import lombok.Data;

@Data
public class ResetPasswordRequest {
    private String passwordResetAuthCode;

    private String newPassword;
}
