package com.akinkemer.securechat.model.mapper;

import com.akinkemer.securechat.model.dto.EnumDto;
import com.akinkemer.securechat.model.entity.Role;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


public class RoleMapper {

    public static EnumDto mapTo(Role entity) {
        EnumDto dto = new EnumDto();
        dto.setKey(entity.getName().name());
        dto.setValue(entity.getName().getScreenLabel());
        return dto;
    }

    public static List<EnumDto> mapToList(Set<Role> roleList) {
        List<EnumDto> dtoList = new ArrayList<>();
        for (Role role : roleList) {
            dtoList.add(mapTo(role));
        }
        return dtoList;
    }
}
