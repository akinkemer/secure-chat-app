package com.akinkemer.securechat.utilities.advice;

import com.akinkemer.securechat.exception.TokenRefreshException;
import com.akinkemer.securechat.utilities.component.ExceptionUtil;
import com.akinkemer.securechat.utilities.exception.SecureChatException;
import org.postgresql.util.PSQLException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.core.NestedRuntimeException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.context.request.WebRequest;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.Enumeration;

public class SecureChatExceptionAdvice {

    private final ExceptionUtil exceptionUtil;

    @Value("${spring.application.name}")
    private String applicationName;

    public SecureChatExceptionAdvice(final ExceptionUtil exceptionUtil) {
        this.exceptionUtil = exceptionUtil;
    }

    @ExceptionHandler(SecureChatException.class)
    public ResponseEntity handleException(SecureChatException exception, HttpServletRequest request) {
        return new ResponseEntity<>(exceptionUtil.convert(exception, getLanguageFormRequestHeader(request), applicationName), exception.getHttpStatus());
    }

    @ExceptionHandler(value = TokenRefreshException.class)
    @ResponseStatus(HttpStatus.FORBIDDEN)
    public ResponseEntity handleTokenRefreshException(TokenRefreshException ex, WebRequest request) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN)
                .body(ex.getMessage());
    }

    @ExceptionHandler(HttpStatusCodeException.class)
    public ResponseEntity<String> handleRestClientException(HttpStatusCodeException ex, HttpServletRequest request) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new String(ex.getResponseBodyAsByteArray(), StandardCharsets.UTF_8));
    }

    @ExceptionHandler(NestedRuntimeException.class)
    public ResponseEntity handleException(NestedRuntimeException exception, HttpServletRequest request) throws Throwable {
        Throwable root = NestedExceptionUtils.getRootCause(exception);
        if (root instanceof SecureChatException) {
            return new ResponseEntity<>(exceptionUtil.convert((SecureChatException) root, getLanguageFormRequestHeader(request), applicationName),
                    ((SecureChatException) root).getHttpStatus());

        } else if (root instanceof PSQLException) {
            PSQLException psqlException = (PSQLException) root;
            if (psqlException.getServerErrorMessage() != null && !StringUtils.isEmpty(psqlException.getServerErrorMessage().getConstraint())) {

                SecureChatException SecureChatException = exceptionUtil.createConstraintAesException(psqlException.getServerErrorMessage());
                if (SecureChatException != null) {
                    return new ResponseEntity<>(exceptionUtil.convert(SecureChatException, getLanguageFormRequestHeader(request), applicationName),
                            SecureChatException.getHttpStatus());
                }
            }
        }
        if (root == null) {
            throw exception;
        }
        throw root;
    }

    private String getLanguageFormRequestHeader(HttpServletRequest request) {
        Enumeration<String> languageRanges = request.getHeaders("Accept-Language");
        if (languageRanges.hasMoreElements()) {
            return languageRanges.nextElement();
        }
        return null;
    }
}
