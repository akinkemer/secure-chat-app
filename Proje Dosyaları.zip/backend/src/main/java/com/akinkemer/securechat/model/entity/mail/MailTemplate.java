package com.akinkemer.securechat.model.entity.mail;

import com.akinkemer.securechat.model.base.ExtendedModel;
import com.akinkemer.securechat.model.type.MailType;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Getter
@Setter
@Entity
public class MailTemplate extends ExtendedModel {

    private final static String SEQUENCE_NAME = "mail_template_id";
    public final static String SPLITTER = ";";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = SEQUENCE_NAME + "_gen")
    @SequenceGenerator(name = SEQUENCE_NAME + "_gen", sequenceName = SEQUENCE_NAME, allocationSize = 1)
    private Long id;

    @Enumerated(EnumType.STRING)
    private MailType type;

    @Column(columnDefinition = "TEXT")
    private String body;

    private String subject;

    private String bodyPlaceHolders;

    private String subjectPlaceHolders;

    private boolean isHtml;

    private String description;

}
