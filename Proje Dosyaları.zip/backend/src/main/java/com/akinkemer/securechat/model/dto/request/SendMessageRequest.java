package com.akinkemer.securechat.model.dto.request;

import com.akinkemer.securechat.model.type.MessageType;
import lombok.Data;

@Data
public class SendMessageRequest {
    String message;

    Long fromUserId;

    Long toUserId;

    Boolean isCertificate;

    Boolean isConnected;
}
