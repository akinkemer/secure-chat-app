package com.akinkemer.securechat.controller;

public abstract class BaseController {
    static final String API = "/api";
    static final String AUTH = API + "/auth";
    static final String PUBLIC = API + "/public";

    //auth
    static final String AUTH_LOGIN = AUTH + "/login";
    static final String AUTH_AUTHENTICATE = AUTH + "/authenticate";
    static final String AUTH_LOGOUT = AUTH + "/logout";
    static final String AUTH_REFRESH_TOKEN = AUTH + "/refreshtoken";
    static final String API_REGISTER = AUTH + "/register";
    static final String API_OWN = API + "/own";
    static final String API_USER_CHANGE_PASSWORD = API + "/changePassword/{userId}";
    static final String API_USER_LIST = API + "/userList";
    static final String API_USER_UPDATE = API + "/userUpdate";
    static final String API_USER_DELETE = API + "/userDelete/{userId}";
    static final String API_USER_CHANGE_ACTIVATE = API + "/user/active/{id}/{isActive}";
    static final String API_USER_ROLES = API + "/userRoles";
    static final String PUBLIC_USER_ROLES = PUBLIC + "/userRoles";
    static final String PUBLIC_FORGOT_PASSWORD = PUBLIC + "/forgotPassword";
    static final String PUBLIC_RESET_PASSWORD = PUBLIC + "/resetPassword";


    //file
    static final String API_DOWNLOAD_FILE = PUBLIC + "/file";

    //users
    static final String API_USERS = API + "/users/{loginUserId}";

    //messages
    static final String API_MESSAGES = API + "/messages";
    static final String API_GROUP_MESSAGE = API + "/messages/group";
    static final String API_PRIVATE_MESSAGES = API + "/messages/private/{senderId}/{receiverId}";
    static final String API_P_AND_ALFA = API + "/messages/pAndAlfa";



}
