package com.akinkemer.securechat.model.dto.request;

import com.akinkemer.securechat.model.type.MailType;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;

@Getter
@Setter
@ToString
public class SendMailRequest {

    private Map<String, String> subjectPlaceHolders = new HashMap<>();

    private Map<String, String> bodyPlaceHolders = new HashMap<>();

    private Map<String, String> imageDatum = new HashMap<>();

    private MailType type;

    private String toAddress;

    private String bccAddress;

    private String ccAddress;

}
