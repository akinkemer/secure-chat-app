package com.akinkemer.securechat.model.dto.request;

import lombok.Data;

@Data
public class ForgetPasswordRequest {
    private String gsmNo;

    private String email;
}
