package com.akinkemer.securechat.model.entity;

import com.akinkemer.securechat.model.base.ExtendedModel;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Getter
@Setter
public class Document extends ExtendedModel {

    public static final String JOIN_COLUMN = "document_id";
    public static final String ID_GENERATOR = "document_id";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = ID_GENERATOR)
    @SequenceGenerator(name = ID_GENERATOR, sequenceName = ID_GENERATOR + "_seq", allocationSize = 1)
    private Long id;

    private String name;

    private String baseUrl;

    private String basePath;

    private String dynamicPath;

    private String publicId;

    private String description;

    public String getPublicAddress() {
        return baseUrl + dynamicPath;
    }

}
