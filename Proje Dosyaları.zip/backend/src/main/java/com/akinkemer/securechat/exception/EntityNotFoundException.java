package com.akinkemer.securechat.exception;

import com.akinkemer.securechat.utilities.exception.SecureChatException;

public class EntityNotFoundException extends SecureChatException implements IErrorCode {

    public EntityNotFoundException(String id, Class clazz) {
        super(ENTITY_NOT_FOUND_EXCEPTION, null, new String[]{id, clazz.getSimpleName()});
    }

}