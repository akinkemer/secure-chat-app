package com.akinkemer.securechat.controller.advice;

import com.akinkemer.securechat.utilities.advice.SecureChatExceptionAdvice;
import com.akinkemer.securechat.utilities.component.ExceptionUtil;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class ControllerExceptionAdvice extends SecureChatExceptionAdvice {

    public ControllerExceptionAdvice(final ExceptionUtil exceptionUtil) {
        super(exceptionUtil);
    }

}
