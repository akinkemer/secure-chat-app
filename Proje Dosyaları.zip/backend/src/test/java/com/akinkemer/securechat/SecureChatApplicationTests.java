package com.akinkemer.securechat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecureChatApplicationTests {

	@Test
	void contextLoads() {
	}

}
