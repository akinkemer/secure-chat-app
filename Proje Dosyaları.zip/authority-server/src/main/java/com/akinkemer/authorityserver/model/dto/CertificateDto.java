package com.akinkemer.authorityserver.model.dto;

import com.akinkemer.authorityserver.model.entity.Certificate;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
public class CertificateDto {
    Long id;
    String publicKey;
    String signature;
    LocalDateTime expiredAt;

    public CertificateDto(Certificate certificate) {
        this.id = certificate.getUserId();
        this.publicKey = certificate.getUserPublicKey();
        this.signature = certificate.getSignature();
        this.expiredAt = certificate.getExpiredAt();
    }

    @Override
    public String toString() {
        return "CertificateDto{" +
                "id=" + id +
                ", publicKey='" + publicKey + '\'' +
                ", signature='" + signature + '\'' +
                ", expiredAt=" + expiredAt +
                '}';
    }
}
