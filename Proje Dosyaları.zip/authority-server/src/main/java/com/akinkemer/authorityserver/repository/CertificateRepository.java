package com.akinkemer.authorityserver.repository;

import com.akinkemer.authorityserver.model.entity.Certificate;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;
import java.util.Optional;

public interface CertificateRepository extends JpaRepository<Certificate, Long> {

    @Query("select cer from Certificate cer " +
            "where cer.userId=:userId " +
            "and cer.userPublicKey=:publicKey " +
            "and cer.expiredAt > current_timestamp ")
    Optional<Certificate> findByUserIdAndAndUserPublicKeyAndExpiredAtAfter(Long userId, String publicKey);
}
