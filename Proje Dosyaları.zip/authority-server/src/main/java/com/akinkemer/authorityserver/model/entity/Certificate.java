package com.akinkemer.authorityserver.model.entity;

import lombok.Data;

import javax.persistence.*;
import java.security.PrivateKey;
import java.time.LocalDateTime;

@Data
@Table
@Entity
public class Certificate {
    public static final String ID_GENERATOR = "certificate_id";

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = ID_GENERATOR)
    @SequenceGenerator(name = ID_GENERATOR, sequenceName = ID_GENERATOR + "_seq", allocationSize = 1)
    private Long id;

    private Long userId;

    private String userPublicKey;

    @Column(columnDefinition = "varchar(1024)")
    private String signaturePublicKey;

    @Column(columnDefinition = "BYTEA")
    private PrivateKey signaturePrivateKey;

    @Column(columnDefinition = "varchar(1024)")
    private String signature;

    private LocalDateTime expiredAt;
}
