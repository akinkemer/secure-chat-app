package com.akinkemer.authorityserver.service;

import com.akinkemer.authorityserver.model.dto.request.AuthenticateUserRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@RequiredArgsConstructor
public class UserAuthenticationService {
    private final RestTemplate restTemplate;

    private static final String URL = "http://localhost:39090/api/auth/authenticate";

    public <T> HttpEntity<T> createHttpEntity(T body) {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        return new HttpEntity<>(body, headers);
    }


    public boolean authenticateUser(Long userId, String token) {

        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(URL);

        AuthenticateUserRequest authenticateUserRequest = new AuthenticateUserRequest(userId, token);

        return restTemplate
                .exchange(builder.toUriString(), HttpMethod.POST, createHttpEntity(authenticateUserRequest), Boolean.class)
                .getBody();
    }

}
