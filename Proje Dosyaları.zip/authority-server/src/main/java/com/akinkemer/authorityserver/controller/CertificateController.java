package com.akinkemer.authorityserver.controller;

import com.akinkemer.authorityserver.model.dto.CertificateDto;
import com.akinkemer.authorityserver.model.dto.request.GenerateCertificateRequest;
import com.akinkemer.authorityserver.service.CertificateService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000", maxAge = 3600)
public class CertificateController {

    private final CertificateService certificateService;

    @PostMapping("/certificate")
    public ResponseEntity<?> generateCertificate(@RequestHeader("Authorization") String token,
                                              @RequestBody GenerateCertificateRequest request) throws Exception {
        return certificateService.generateCertificate(token, request);
    }

    @PostMapping("/verify")
    public ResponseEntity<?> verifyCertificate(@RequestBody CertificateDto dto) throws Exception {
        return certificateService.verifyCertificate(dto);
    }
}
