package com.akinkemer.authorityserver.model.dto.request;

import lombok.Data;

@Data
public class GenerateCertificateRequest {
    Long userId;
    String publicKey;
}
