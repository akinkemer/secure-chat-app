package com.akinkemer.authorityserver.service;

import com.akinkemer.authorityserver.model.dto.CertificateDto;
import com.akinkemer.authorityserver.model.dto.request.GenerateCertificateRequest;
import com.akinkemer.authorityserver.model.entity.Certificate;
import com.akinkemer.authorityserver.repository.CertificateRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.crypto.Cipher;
import java.security.*;
import java.time.LocalDateTime;
import java.util.Base64;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class CertificateService {

    private final CertificateRepository certificateRepository;

    private final UserAuthenticationService userAuthenticationService;

    public ResponseEntity<?> generateCertificate(String token, GenerateCertificateRequest request) throws Exception {
        Boolean isUserAuthenticated = userAuthenticationService.authenticateUser(request.getUserId(), token);

        if (!isUserAuthenticated) {
            return ResponseEntity.badRequest().body("Kullanıcıyı doğrulama başarısız");
        }

        System.out.println("request.getUserId() " + request.getUserId() + " request.getPublicKey() " + request.getPublicKey());
        Optional<Certificate> optionalCertificate = certificateRepository
                .findByUserIdAndAndUserPublicKeyAndExpiredAtAfter(request.getUserId(), request.getPublicKey());

        if (optionalCertificate.isPresent()) {
            return ResponseEntity.ok().body(new CertificateDto(optionalCertificate.get()));
        }

        Certificate certificate = new Certificate();
        certificate.setUserId(request.getUserId());
        certificate.setExpiredAt(LocalDateTime.now().plusDays(10));
        certificate.setUserPublicKey(request.getPublicKey());

        KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
        generator.initialize(1024);
        KeyPair pair = generator.generateKeyPair();
        PrivateKey privateKey = pair.getPrivate();
        PublicKey publicKey = pair.getPublic();

        certificate.setSignaturePublicKey(encode(publicKey.getEncoded()));
        certificate.setSignaturePrivateKey(privateKey);

        certificate.setSignature(encrypt(request.getPublicKey(), publicKey));

        certificateRepository.save(certificate);

        return ResponseEntity.ok().body(new CertificateDto(certificate));
    }

    public ResponseEntity<?> verifyCertificate(CertificateDto dto) throws Exception {

        Optional<Certificate> optionalCertificate = certificateRepository
                .findByUserIdAndAndUserPublicKeyAndExpiredAtAfter(dto.getId(), dto.getPublicKey());


        if (!optionalCertificate.isPresent()) {
            return ResponseEntity.badRequest().body("Sertifika doğrulama işlemi başarısız");
        }

        Certificate certificate = optionalCertificate.get();

        if (dto.getPublicKey().equals(decrypt(certificate.getSignature(), certificate.getSignaturePrivateKey()))) {
            return ResponseEntity.ok().body("Sertifika geçerli");
        }

        return ResponseEntity.badRequest().body("Sertifika doğrulama işlemi başarısız");

    }

    public String encrypt(String message, PublicKey publicKey) throws Exception {
        byte[] messageToBytes = message.getBytes();
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, publicKey);
        byte[] encryptedBytes = cipher.doFinal(messageToBytes);
        return encode(encryptedBytes);
    }

    public String decrypt(String encryptedMessage, PrivateKey privateKey) throws Exception {
        byte[] encryptedBytes = decode(encryptedMessage);
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, privateKey);
        byte[] decryptedMessage = cipher.doFinal(encryptedBytes);
        return new String(decryptedMessage, "UTF8");
    }

    private byte[] decode(String data) {
        return Base64.getDecoder().decode(data);
    }

    private String encode(byte[] data) {
        return Base64.getEncoder().encodeToString(data);
    }


}
